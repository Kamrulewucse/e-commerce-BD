@extends('layouts.app')
@section('style')
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        .email-section {
            background-color: #f5f5f5;
            padding: 35px 50px;
        }
        .email-title {
            font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
            font-weight: 400;
            font-style: normal;
            font-weight: 700;
            font-size: 2.125rem;
            line-height: 1.0588235294117647;
            letter-spacing: 0;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .email-section-left {
            padding: 3rem;
            box-sizing: border-box;
            padding-left: 6.4vw;
            padding-right: 6.4vw;
        }
        .email-section-content{
            background: #fff;
            padding: 2rem;
        }
        .email-us-mandatory{
            display: flex;
            flex-direction: row;
            align-content: end;
            padding: 5px 0px;
        }
        .email-form{
            background: #fff;
            padding: 2rem;
        }
        label {
            color: #19110b;
            display: block;
            margin: 0 0 0.5rem;
            font-weight: 400;
            font-size: 1.3rem;
            line-height: 1.4285714285714286;
            letter-spacing: .4px;
            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
        }
        select {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            color: #19110b;
            height: 4rem;
            text-align: left;
            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
            font-weight: 400;
            font-style: normal;
            font-weight: 500;
            font-size: 1.3rem;
            line-height: 2;
            letter-spacing: .4px;
            transition: border .3s cubic-bezier(0.39,0.575,0.565,1);
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background: #fff url(data:image/svg+xml;charset=utf8,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2080%2080'%20focusable='false'%20aria-hidden='true'%20class='ui-icon-controls-chevron-down'%3E%3Cpath%20fill='%2319110b'%20fill-rule='evenodd'%20d='M46.2%2048.6L17.8%2020.3l-5.5%205.4%2028.4%2028.4%205.4%205.5.1.1.1-.1%205.3-4.5L80%2026.7l-5.5-6.4-28.3%2028.3z'/%3E%3C/svg%3E) no-repeat right 1rem top 50%;
            background-size: 1rem 1rem;
            padding: 0 2rem 0 1rem;
            text-overflow: ellipsis;
            width: 100%;
        }

        input{
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            color: #19110b;
            width: 100%;
            background-size: 1rem 1rem;
            padding: 0 2rem 0 1rem;
            height: 4rem;
            line-height: 2;
            letter-spacing: .4px;
        }
        .input-col{
            display: block;
            margin-bottom: 2.5rem;
        }
        .phone-number-section select{
            width: 32%;
        }
        .phone-number-section input{
            width: 66%;
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            font-size: 1.3rem;
            line-height: 2;
            letter-spacing: .4px;
            margin-left: 3px;
            margin-top: 2px;
        }
        textarea {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            color: #19110b;
            height: 4rem;
            text-align: left;
            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
            font-weight: 400;
            font-style: normal;
            font-weight: 500;
            font-size: 1rem;
            line-height: 2;
            letter-spacing: .4px;
            transition: border .3s cubic-bezier(0.39,0.575,0.565,1);
            height: 10rem;
            padding: 0.6875rem 1rem;
            width: 100%;
        }
        .send-email-btn{
            margin-top: 2.5rem;
            display: flex;
            justify-content: flex-end;
        }
        .send-email-btn button {
            align-items: center;
            align-content: center;
            -webkit-appearance: none;
            border: 0 none;
            border-radius: 0;
            box-sizing: border-box;
            cursor: pointer;
            display: inline-flex;
            min-height: 4rem;
            padding: 1.5rem 2.5rem;
            font-weight: 400;
            font-size: 1.5rem;
            line-height: 1.25;
            letter-spacing: .4px;
            font-family: inherit;
            justify-content: center;
            background: #19110b;
            color: #fff;
        }
        .email-use-page-footer {
            font-weight: 300;
            font-size: 1rem;
            line-height: 2;
            letter-spacing: .4px;
            margin: 2.5rem 0 0 0;
            border-top:1px solid #eae8e4;
            padding: 30px 0px;
        }

        @media only screen and (max-width: 600px) {
            .email-section {
                background-color: #f5f5f5;
                padding: 0px 0px;
            }
            .email-section-content{
                margin-top: 45px;
            }
        }
        @media only screen and (min-width: 64em) {
            .email-use-page-footer {
                border-top: #eae8e4 1px solid;
                margin-top: 2.5rem;
                padding-top: 2.5rem;
            }
        }
        .has-error{
            color:red;
        }
        .error{
            border-color:red;
        }
        h1.other-box-title {
            font-weight: bold;
            font-size: 20px;
        }
    </style>
    <style>

        ul.filter-list li:first-child,ul.filter-list li{
            font-size: 16px;
            cursor: auto;
            padding: 0;
            border-left: 0px solid #eee;
            color: #000;
        }
        ul.filter-list {
            padding: 0;
        }
        ul.filter-list li{
            display: inline-block;
        }
        ul.filter-list li a {
            display: inline-block;
            padding: 23px 25px;
            transition: all 0.5s ease;
            margin: 0;
            border-left: 1px solid #eee;
        }
        ul.filter-list li a:hover{
            box-shadow: inset 0 -1px 0 0 #19110b;
        }
        ul.filter-list li a.other-page-active{
            box-shadow: inset 0 -4px 0 0 #19110b;
        }
        .other-page-content-area {
            background: #f6f5f3;
            padding: 50px 0;
        }

        h1.contact-page-title {
            font-weight: bold;
            font-size: 32px;
            border-bottom: #eae8e4 1px solid;
            margin-bottom: 25px;
            padding-bottom: 17px;
        }
        .other-page-box {
            border: 1px solid #eae8e4;
            background: #fff;
            padding: 2rem;
            margin: 7px 0;
        }
        h1.other-box-title {
            font-weight: bold;
            font-size: 20px;
        }
        a.send-and-email{
            align-items: center;
            align-content: center;
            -webkit-appearance: none;
            border: 0 none;
            border-radius: 0;
            box-sizing: border-box;
            cursor: pointer;
            display: inline-flex;
            min-height: 3rem;
            font-weight: 400;
            line-height: 1.25;
            letter-spacing: .4px;
            font-family: inherit;
            justify-content: center;
            transition: border .3s cubic-bezier(0.39,0.575,0.565,1),box-shadow .3s cubic-bezier(0.39,0.575,0.565,1),color .3s cubic-bezier(0.39,0.575,0.565,1),background .3s cubic-bezier(0.39,0.575,0.565,1);
            background: rgba(234,232,228,0);
            box-shadow: inset 0 0 0 1px #19110b;
            color: #19110b;
            width: 100%;
            padding: 19px 0;
            font-size: 15px;
            margin: 10px 0;
        }
        a.send-and-email:hover{
            background-color: #eae8e4;
            box-shadow: inset 0 0 0 1px #eae8e4;
            color: #19110b;
        }

        .other-select-country-list select {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            color: #19110b;
            height: 3rem;
            text-align: left;
            font-family: "Louis Vuitton Web","Helvetica Neue",Helvetica,Arial,sans-serif;
            font-style: normal;
            font-weight: 500;
            font-size: 1rem;
            line-height: 2;
            letter-spacing: .4px;
            transition: border .3s cubic-bezier(0.39,0.575,0.565,1);
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background: #fff url("data:image/svg+xml;charset=utf8,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2080%2080'%20focusable='false'%20aria-hidden='true'%20class='ui-icon-controls-chevron-down'%3E%3Cpath%20fill='%2319110b'%20fill-rule='evenodd'%20d='M46.2%2048.6L17.8%2020.3l-5.5%205.4%2028.4%2028.4%205.4%205.5.1.1.1-.1%205.3-4.5L80%2026.7l-5.5-6.4-28.3%2028.3z'/%3E%3C/svg%3E") no-repeat right 1rem top 50%;
            background-size: 1rem 1rem;
            max-width: 100%;
            padding: 0 2rem 0 1rem;
            position: relative;
            text-overflow: ellipsis;
        }
        .other-select-country-list select {
            width: 100%;
            height: 50px;
            font-size: 14px;
        }
        .fall-back i{
            margin-left: 10px;
            padding: 30px 50px;
            background:#fff;
            color: #000;
        }
        .fall-back i:hover{
            background:#EAE8E4;
            color: #000;
        }
    </style>
@endsection

@section('content')
    @include('frontend.partial.other_page_nav')
    <div class="row body-height-full">
        <div class="email-section" style="background-color: #f5f5f5; padding: 2px 50px 35px 50px;">
{{--            <div class="fall-back">--}}
{{--                <a href="{{ route('start_the_journey') }}"><i class="fa fa-long-arrow-left"></i></a>--}}
{{--            </div>--}}
            <div class="col-12 col-sm-12 col-md-8 col-xl-8 email-section-left">
                @if(Session::has('status'))
                    <div class="alert alert-success">{{ Session()->get('status') }}</div>
                @endif
                 <h1 class="other-box-title">EMAIL US</h1>
                <p class="email-section-content">Please provide the following information and the client service will answer your enquiry as quickly as possible. You can also visit the FAQ section where you can find the list of the most frequently asked questions.</p>
                <div class="col-12 col-sm-12 email-us-mandatory d-flex justify-content-end">
                    <p>
                        <b>Mandatory fields<exp style="color: darkred">*</exp></b>
                    </p>
                </div>
                <div class="col-12 col-sm-12">
                    <form action="{{ route('email.us') }}" method="post">
                        @csrf
                        <div class="email-form">
                            <div class="input-col">
                                <label for="" class="{{ $errors->has('name_title') ? 'has-error' :'' }}">
                                    Title*
                                </label>
                                <div class="inputColumnTable">
                                    <div class="inputColumnRow">
                                        <select id="" aria-describedby="" name="name_title" aria-invalid="false" class="{{ $errors->has('name_title') ? 'error' :'' }}">
                                            <option id="" selected="selected" value="" disabled="disabled" >
                                                Select:
                                            </option>
                                            <option value="Mr">
                                                Mr
                                            </option>
                                            <option value="Mrs">
                                                Mrs
                                            </option>
                                            <option value="Mx">
                                                Mx
                                            </option>
                                            <option value="Unknown">
                                                Prefer not to say
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="input-col">
                                <label for="firstName" class="fieldLabel {{ $errors->has('firstName') ? 'has-error' :'' }}">
                                    First name*
                                </label>
                                <div class="inputColumn">
                                    <div class="inputColumnTable">
                                        <div class="inputColumnRow">
                                            <input id="firstName" aria-describedby="firstNameDescription firstNameError" maxlength="40" dir="auto" name="firstName" aria-invalid="false" value="" type="text" class="{{ $errors->has('firstName') ? 'error' :'' }}">
                                            {{-- <input name="_D:/atg/userprofiling/ProfileFormHandler.value.firstName" value=" " type="hidden"> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="input-col">
                                <label for="email" class="fieldLabel {{ $errors->has('email') ? 'has-error' :'' }}">
                                    E-mail Address*
                                </label>
                                <div class="inputColumn">
                                    <div class="inputColumnTable">
                                        <div class="inputColumnRow">
                                            <input class="{{ $errors->has('email') ? 'error' :'' }}" id="email" aria-describedby="emailDescription emailError" maxlength="50" dir="auto" aria-invalid="false" name="email" autocorrect="off" value="" autocomplete="off" type="email" autocapitalize="off">
                                            {{-- <input name="_D:/atg/userprofiling/ProfileFormHandler.value.email" value=" " type="hidden"> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="input-col">
                                <label for=""  class="{{ $errors->has('country') ? 'has-error' :'' }}">
                                    Country/Region*
                                </label>
                                <div class="inputColumnTable">
                                    <div class="inputColumnRow">
                                        <input name="country" value=" " type="hidden">
                                        <select id="" aria-describedby="" name="country" aria-invalid="false" class="{{ $errors->has('country') ? 'error' :'' }}">
                                            <option id="" selected="selected" value="" disabled="disabled">
                                                Select your Country/Region
                                            </option>
                                            <option value="AF">
                                                Afghanistan
                                            </option>
                                            <option value="AL">
                                                Albania
                                            </option>
                                            <option value="DZ">
                                                Algeria
                                            </option>
                                            <option value="AS">
                                                American Samoa
                                            </option>
                                            <option value="AD">
                                                Andorra
                                            </option>
                                            <option value="AO">
                                                Angola
                                            </option>
                                            <option value="AI">
                                                Anguilla
                                            </option>
                                            <option value="AQ">
                                                Antarctica
                                            </option>
                                            <option value="AG">
                                                Antigua And Barbuda
                                            </option>
                                            <option value="AR">
                                                Argentina
                                            </option>
                                            <option value="AM">
                                                Armenia
                                            </option>
                                            <option value="AW">
                                                Aruba
                                            </option>
                                            <option value="AU">
                                                Australia
                                            </option>
                                            <option value="AT">
                                                Austria
                                            </option>
                                            <option value="AZ">
                                                Azerbaijan
                                            </option>
                                            <option value="BS">
                                                Bahamas
                                            </option>
                                            <option value="BH">
                                                Bahrain
                                            </option>
                                            <option value="BD">
                                                Bangladesh
                                            </option>
                                            <option value="BB">
                                                Barbados
                                            </option>
                                            <option value="BY">
                                                Belarus
                                            </option>
                                            <option value="BE">
                                                Belgium
                                            </option>
                                            <option value="BZ">
                                                Belize
                                            </option>
                                            <option value="BJ">
                                                Benin
                                            </option>
                                            <option value="BM">
                                                Bermuda
                                            </option>
                                            <option value="BT">
                                                Bhutan
                                            </option>
                                            <option value="BO">
                                                Bolivia
                                            </option>
                                            <option value="BA">
                                                Bosnia And Herzegovina
                                            </option>
                                            <option value="BW">
                                                Botswana
                                            </option>
                                            <option value="BV">
                                                Bouvet Island
                                            </option>
                                            <option value="BR">
                                                Brazil
                                            </option>
                                            <option value="IO">
                                                British Indian Ocean Territory
                                            </option>
                                            <option value="BN">
                                                Brunei Darussalam
                                            </option>
                                            <option value="BG">
                                                Bulgaria
                                            </option>
                                            <option value="BF">
                                                Burkina Faso
                                            </option>
                                            <option value="BI">
                                                Burundi
                                            </option>
                                            <option value="KH">
                                                Cambodia
                                            </option>
                                            <option value="CM">
                                                Cameroon
                                            </option>
                                            <option value="CA">
                                                Canada
                                            </option>
                                            <option value="CV">
                                                Cape Verde
                                            </option>
                                            <option value="KY">
                                                Cayman Islands
                                            </option>
                                            <option value="CF">
                                                Central African Republic
                                            </option>
                                            <option value="TD">
                                                Chad
                                            </option>
                                            <option value="CL">
                                                Chile
                                            </option>
                                            <option value="CN">
                                                China
                                            </option>
                                            <option value="CX">
                                                Christmas Island
                                            </option>
                                            <option value="CC">
                                                Cocos (Keeling) Islands
                                            </option>
                                            <option value="CO">
                                                Colombia
                                            </option>
                                            <option value="KM">
                                                Comoros
                                            </option>
                                            <option value="CG">
                                                Congo
                                            </option>
                                            <option value="CK">
                                                Cook Islands
                                            </option>
                                            <option value="CR">
                                                Costa Rica
                                            </option>
                                            <option value="CI">
                                                Cote D'Ivoire
                                            </option>
                                            <option value="HR">
                                                Croatia
                                            </option>
                                            <option value="CU">
                                                Cuba
                                            </option>
                                            <option value="CY">
                                                Cyprus
                                            </option>
                                            <option value="CZ">
                                                Czech Republic
                                            </option>
                                            <option value="KP">
                                                Democratic People'S Republic Of Korea
                                            </option>
                                            <option value="DK">
                                                Denmark
                                            </option>
                                            <option value="DJ">
                                                Djibouti
                                            </option>
                                            <option value="DM">
                                                Dominica
                                            </option>
                                            <option value="DO">
                                                Dominican Republic
                                            </option>
                                            <option value="EC">
                                                Ecuador
                                            </option>
                                            <option value="EG">
                                                Egypt
                                            </option>
                                            <option value="SV">
                                                El Salvador
                                            </option>
                                            <option value="GQ">
                                                Equatorial Guinea
                                            </option>
                                            <option value="ER">
                                                Eritrea
                                            </option>
                                            <option value="EE">
                                                Estonia
                                            </option>
                                            <option value="ET">
                                                Ethiopia
                                            </option>
                                            <option value="FK">
                                                Falkland Islands (Malvinas)
                                            </option>
                                            <option value="FO">
                                                Faroe Islands
                                            </option>
                                            <option value="FM">
                                                Federated States Of Micronesia
                                            </option>
                                            <option value="FJ">
                                                Fiji
                                            </option>
                                            <option value="FI">
                                                Finland
                                            </option>
                                            <option value="FR">
                                                France
                                            </option>
                                            <option value="GF">
                                                French Guiana
                                            </option>
                                            <option value="PF">
                                                French Polynesia
                                            </option>
                                            <option value="TF">
                                                French Southern Territories
                                            </option>
                                            <option value="GA">
                                                Gabon
                                            </option>
                                            <option value="GM">
                                                Gambia
                                            </option>
                                            <option value="GE">
                                                Georgia
                                            </option>
                                            <option value="DE">
                                                Germany
                                            </option>
                                            <option value="GH">
                                                Ghana
                                            </option>
                                            <option value="GI">
                                                Gibraltar
                                            </option>
                                            <option value="GR">
                                                Greece
                                            </option>
                                            <option value="GL">
                                                Greenland
                                            </option>
                                            <option value="GD">
                                                Grenada
                                            </option>
                                            <option value="GP">
                                                Guadeloupe
                                            </option>
                                            <option value="GU">
                                                Guam
                                            </option>
                                            <option value="GT">
                                                Guatemala
                                            </option>
                                            <option value="GN">
                                                Guinea
                                            </option>
                                            <option value="GW">
                                                Guinea-Bissau
                                            </option>
                                            <option value="GY">
                                                Guyana
                                            </option>
                                            <option value="HT">
                                                Haiti
                                            </option>
                                            <option value="HM">
                                                Heard Island And Mcdonald Islands
                                            </option>
                                            <option value="VA">
                                                Holy See (Vatican City State)
                                            </option>
                                            <option value="HN">
                                                Honduras
                                            </option>
                                            <option value="HK">
                                                Hong Kong SAR
                                            </option>
                                            <option value="HU">
                                                Hungary
                                            </option>
                                            <option value="IS">
                                                Iceland
                                            </option>
                                            <option value="IN">
                                                India
                                            </option>
                                            <option value="ID">
                                                Indonesia
                                            </option>
                                            <option value="IQ">
                                                Iraq
                                            </option>
                                            <option value="IE">
                                                Ireland
                                            </option>
                                            <option value="IR">
                                                Islamic Republic Of Iran
                                            </option>
                                            <option value="IL">
                                                Israel
                                            </option>
                                            <option value="IT">
                                                Italy
                                            </option>
                                            <option value="JM">
                                                Jamaica
                                            </option>
                                            <option value="JP">
                                                Japan
                                            </option>
                                            <option value="JO">
                                                Jordan
                                            </option>
                                            <option value="KZ">
                                                Kazakhstan
                                            </option>
                                            <option value="KE">
                                                Kenya
                                            </option>
                                            <option value="KI">
                                                Kiribati
                                            </option>
                                            <option value="KR">
                                                Korea
                                            </option>
                                            <option value="KW">
                                                Kuwait
                                            </option>
                                            <option value="KG">
                                                Kyrgyzstan
                                            </option>
                                            <option value="LA">
                                                Lao People'S Democratic Republic
                                            </option>
                                            <option value="LV">
                                                Latvia
                                            </option>
                                            <option value="LB">
                                                Lebanon
                                            </option>
                                            <option value="LS">
                                                Lesotho
                                            </option>
                                            <option value="LR">
                                                Liberia
                                            </option>
                                            <option value="LY">
                                                Libyan Arab Jamahiriya
                                            </option>
                                            <option value="LI">
                                                Liechtenstein
                                            </option>
                                            <option value="LT">
                                                Lithuania
                                            </option>
                                            <option value="LU">
                                                Luxembourg
                                            </option>
                                            <option value="MO">
                                                Macau SAR
                                            </option>
                                            <option value="MG">
                                                Madagascar
                                            </option>
                                            <option value="MW">
                                                Malawi
                                            </option>
                                            <option value="MY">
                                                Malaysia
                                            </option>
                                            <option value="MV">
                                                Maldives
                                            </option>
                                            <option value="ML">
                                                Mali
                                            </option>
                                            <option value="MT">
                                                Malta
                                            </option>
                                            <option value="MH">
                                                Marshall Islands
                                            </option>
                                            <option value="MQ">
                                                Martinique
                                            </option>
                                            <option value="MR">
                                                Mauritania
                                            </option>
                                            <option value="MU">
                                                Mauritius
                                            </option>
                                            <option value="YT">
                                                Mayotte
                                            </option>
                                            <option value="MX">
                                                Mexico
                                            </option>
                                            <option value="MC">
                                                Monaco
                                            </option>
                                            <option value="MN">
                                                Mongolia
                                            </option>
                                            <option value="MS">
                                                Montserrat
                                            </option>
                                            <option value="MA">
                                                Morocco
                                            </option>
                                            <option value="MZ">
                                                Mozambique
                                            </option>
                                            <option value="MM">
                                                Myanmar
                                            </option>
                                            <option value="NA">
                                                Namibia
                                            </option>
                                            <option value="NR">
                                                Nauru
                                            </option>
                                            <option value="NP">
                                                Nepal
                                            </option>
                                            <option value="NL">
                                                Netherlands
                                            </option>
                                            <option value="AN">
                                                Netherlands Antilles
                                            </option>
                                            <option value="NC">
                                                New Caledonia
                                            </option>
                                            <option value="NZ">
                                                New Zealand
                                            </option>
                                            <option value="NI">
                                                Nicaragua
                                            </option>
                                            <option value="NE">
                                                Niger
                                            </option>
                                            <option value="NG">
                                                Nigeria
                                            </option>
                                            <option value="NU">
                                                Niue
                                            </option>
                                            <option value="NF">
                                                Norfolk Island
                                            </option>
                                            <option value="MP">
                                                Northern Mariana Islands
                                            </option>
                                            <option value="NO">
                                                Norway
                                            </option>
                                            <option value="PS">
                                                Occupied Palestinian Territory
                                            </option>
                                            <option value="OM">
                                                Oman
                                            </option>
                                            <option value="PK">
                                                Pakistan
                                            </option>
                                            <option value="PW">
                                                Palau
                                            </option>
                                            <option value="PA">
                                                Panama
                                            </option>
                                            <option value="PG">
                                                Papua New Guinea
                                            </option>
                                            <option value="PY">
                                                Paraguay
                                            </option>
                                            <option value="PE">
                                                Peru
                                            </option>
                                            <option value="PH">
                                                Philippines
                                            </option>
                                            <option value="PN">
                                                Pitcairn
                                            </option>
                                            <option value="PL">
                                                Poland
                                            </option>
                                            <option value="PT">
                                                Portugal
                                            </option>
                                            <option value="PR">
                                                Puerto Rico
                                            </option>
                                            <option value="QA">
                                                Qatar
                                            </option>
                                            <option value="MD">
                                                Republic Of Moldova
                                            </option>
                                            <option value="RE">
                                                Reunion
                                            </option>
                                            <option value="RO">
                                                Romania
                                            </option>
                                            <option value="RU">
                                                Russian Federation
                                            </option>
                                            <option value="RW">
                                                Rwanda
                                            </option>
                                            <option value="SH">
                                                Saint Helena
                                            </option>
                                            <option value="KN">
                                                Saint Kitts And Nevis
                                            </option>
                                            <option value="LC">
                                                Saint Lucia
                                            </option>
                                            <option value="PM">
                                                Saint Pierre And Miquelon
                                            </option>
                                            <option value="VC">
                                                Saint Vincent And The Grenadines
                                            </option>
                                            <option value="WS">
                                                Samoa
                                            </option>
                                            <option value="SM">
                                                San Marino
                                            </option>
                                            <option value="ST">
                                                Sao Tome And Principe
                                            </option>
                                            <option value="SA">
                                                Saudi Arabia
                                            </option>
                                            <option value="SN">
                                                Senegal
                                            </option>
                                            <option value="RS">
                                                Serbie
                                            </option>
                                            <option value="SC">
                                                Seychelles
                                            </option>
                                            <option value="SL">
                                                Sierra Leone
                                            </option>
                                            <option value="SG">
                                                Singapore
                                            </option>
                                            <option value="SK">
                                                Slovakia
                                            </option>
                                            <option value="SI">
                                                Slovenia
                                            </option>
                                            <option value="SB">
                                                Solomon Islands
                                            </option>
                                            <option value="SO">
                                                Somalia
                                            </option>
                                            <option value="ZA">
                                                South Africa
                                            </option>
                                            <option value="GS">
                                                South Georgia And The South Sandwich Islands
                                            </option>
                                            <option value="ES">
                                                Spain
                                            </option>
                                            <option value="LK">
                                                Sri Lanka
                                            </option>
                                            <option value="SD">
                                                Sudan
                                            </option>
                                            <option value="SR">
                                                Suriname
                                            </option>
                                            <option value="SJ">
                                                Svalbard And Jan Mayen
                                            </option>
                                            <option value="SZ">
                                                Swaziland
                                            </option>
                                            <option value="SE">
                                                Sweden
                                            </option>
                                            <option value="CH">
                                                Switzerland
                                            </option>
                                            <option value="SY">
                                                Syrian Arab Republic
                                            </option>
                                            <option value="TW">
                                                Taiwan
                                            </option>
                                            <option value="TJ">
                                                Tajikistan
                                            </option>
                                            <option value="TH">
                                                Thailand
                                            </option>
                                            <option value="CD">
                                                The Democratic Republic Of The Congo
                                            </option>
                                            <option value="MK">
                                                The Former Yugoslav Republic Of Macedonia
                                            </option>
                                            <option value="TL">
                                                Timor-Leste
                                            </option>
                                            <option value="TG">
                                                Togo
                                            </option>
                                            <option value="TK">
                                                Tokelau
                                            </option>
                                            <option value="TO">
                                                Tonga
                                            </option>
                                            <option value="TT">
                                                Trinidad And Tobago
                                            </option>
                                            <option value="TN">
                                                Tunisia
                                            </option>
                                            <option value="TR">
                                                Turkey
                                            </option>
                                            <option value="TM">
                                                Turkmenistan
                                            </option>
                                            <option value="TC">
                                                Turks And Caicos Islands
                                            </option>
                                            <option value="TV">
                                                Tuvalu
                                            </option>
                                            <option value="UG">
                                                Uganda
                                            </option>
                                            <option value="UA">
                                                Ukraine
                                            </option>
                                            <option value="AE">
                                                United Arab Emirates
                                            </option>
                                            <option value="GB">
                                                United Kingdom
                                            </option>
                                            <option value="TZ">
                                                United Republic Of Tanzania
                                            </option>
                                            <option value="US">
                                                United States
                                            </option>
                                            <option value="UM">
                                                United States Minor Outlying Islands
                                            </option>
                                            <option value="UY">
                                                Uruguay
                                            </option>
                                            <option value="UZ">
                                                Uzbekistan
                                            </option>
                                            <option value="VU">
                                                Vanuatu
                                            </option>
                                            <option value="VE">
                                                Venezuela
                                            </option>
                                            <option value="VN">
                                                Viet Nam
                                            </option>
                                            <option value="VG">
                                                Virgin Islands, British
                                            </option>
                                            <option value="VI">
                                                Virgin Islands, U.S.
                                            </option>
                                            <option value="WF">
                                                Wallis And Futuna
                                            </option>
                                            <option value="EH">
                                                Western Sahara
                                            </option>
                                            <option value="YE">
                                                Yemen
                                            </option>
                                            <option value="ZM">
                                                Zambia
                                            </option>
                                            <option value="ZW">
                                                Zimbabwe
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="input-col ">
                                <label for=" emailUsPhoneNumber " class="fieldLabel ">
                                    Phone
                                </label>
                                <div class="inputColumn">
                                    <div class="inputColumnTable">
                                        <div class="phone-number-section">
                                            <select id="" aria-describedby="" title=" Country code " name="number_prefix" aria-invalid="false">
                                                <option value="US">
                                                    +1
                                                </option>
                                                <option value="RU">
                                                    +7
                                                </option>
                                                <option value="EG">
                                                    +20
                                                </option>
                                                <option value="ZA">
                                                    +27
                                                </option>
                                                <option value="GR">
                                                    +30
                                                </option>
                                                <option value="NL">
                                                    +31
                                                </option>
                                                <option value="BE">
                                                    +32
                                                </option>
                                                <option value="FR">
                                                    +33
                                                </option>
                                                <option value="ES">
                                                    +34
                                                </option>
                                                <option value="HU">
                                                    +36
                                                </option>
                                                <option value="IT">
                                                    +39
                                                </option>
                                                <option value="RO">
                                                    +40
                                                </option>
                                                <option value="CH">
                                                    +41
                                                </option>
                                                <option value="AT">
                                                    +43
                                                </option>
                                                <option value="GB">
                                                    +44
                                                </option>
                                                <option value="DK">
                                                    +45
                                                </option>
                                                <option value="SE">
                                                    +46
                                                </option>
                                                <option value="NO">
                                                    +47
                                                </option>
                                                <option value="PL">
                                                    +48
                                                </option>
                                                <option value="DE">
                                                    +49
                                                </option>
                                                <option value="PE">
                                                    +51
                                                </option>
                                                <option value="MX">
                                                    +52
                                                </option>
                                                <option value="CU">
                                                    +53
                                                </option>
                                                <option value="AR">
                                                    +54
                                                </option>
                                                <option value="BR">
                                                    +55
                                                </option>
                                                <option value="CL">
                                                    +56
                                                </option>
                                                <option value="CO">
                                                    +57
                                                </option>
                                                <option value="VE">
                                                    +58
                                                </option>
                                                <option value="MY">
                                                    +60
                                                </option>
                                                <option value="AU">
                                                    +61
                                                </option>
                                                <option value="ID">
                                                    +62
                                                </option>
                                                <option value="PH">
                                                    +63
                                                </option>
                                                <option value="NZ">
                                                    +64
                                                </option>
                                                <option value="SG">
                                                    +65
                                                </option>
                                                <option value="TH">
                                                    +66
                                                </option>
                                                <option value="JP">
                                                    +81
                                                </option>
                                                <option value="KR">
                                                    +82
                                                </option>
                                                <option value="VN">
                                                    +84
                                                </option>
                                                <option value="CN">
                                                    +86
                                                </option>
                                                <option value="TR">
                                                    +90
                                                </option>
                                                <option value="IN">
                                                    +91
                                                </option>
                                                <option value="PK">
                                                    +92
                                                </option>
                                                <option value="AF">
                                                    +93
                                                </option>
                                                <option value="LK">
                                                    +94
                                                </option>
                                                <option value="MM">
                                                    +95
                                                </option>
                                                <option value="IR">
                                                    +98
                                                </option>
                                                <option value="MA">
                                                    +212
                                                </option>
                                                <option value="DZ">
                                                    +213
                                                </option>
                                                <option value="TN">
                                                    +216
                                                </option>
                                                <option value="LY">
                                                    +218
                                                </option>
                                                <option value="GM">
                                                    +220
                                                </option>
                                                <option value="SN">
                                                    +221
                                                </option>
                                                <option value="MR">
                                                    +222
                                                </option>
                                                <option value="ML">
                                                    +223
                                                </option>
                                                <option value="GN">
                                                    +224
                                                </option>
                                                <option value="CI">
                                                    +225
                                                </option>
                                                <option value="BF">
                                                    +226
                                                </option>
                                                <option value="NE">
                                                    +227
                                                </option>
                                                <option value="TG">
                                                    +228
                                                </option>
                                                <option value="BJ">
                                                    +229
                                                </option>
                                                <option value="MU">
                                                    +230
                                                </option>
                                                <option value="LR">
                                                    +231
                                                </option>
                                                <option value="SL">
                                                    +232
                                                </option>
                                                <option value="GH">
                                                    +233
                                                </option>
                                                <option value="NG">
                                                    +234
                                                </option>
                                                <option value="TD">
                                                    +235
                                                </option>
                                                <option value="CF">
                                                    +236
                                                </option>
                                                <option value="CM">
                                                    +237
                                                </option>
                                                <option value="CV">
                                                    +238
                                                </option>
                                                <option value="ST">
                                                    +239
                                                </option>
                                                <option value="GQ">
                                                    +240
                                                </option>
                                                <option value="GA">
                                                    +241
                                                </option>
                                                <option value="CG">
                                                    +242
                                                </option>
                                                <option value="CD">
                                                    +243
                                                </option>
                                                <option value="AO">
                                                    +244
                                                </option>
                                                <option value="GW">
                                                    +245
                                                </option>
                                                <option value="IO">
                                                    +246
                                                </option>
                                                <option value="SC">
                                                    +248
                                                </option>
                                                <option value="SD">
                                                    +249
                                                </option>
                                                <option value="RW">
                                                    +250
                                                </option>
                                                <option value="ET">
                                                    +251
                                                </option>
                                                <option value="SO">
                                                    +252
                                                </option>
                                                <option value="DJ">
                                                    +253
                                                </option>
                                                <option value="KE">
                                                    +254
                                                </option>
                                                <option value="TZ">
                                                    +255
                                                </option>
                                                <option value="UG">
                                                    +256
                                                </option>
                                                <option value="BI">
                                                    +257
                                                </option>
                                                <option value="MZ">
                                                    +258
                                                </option>
                                                <option value="ZM">
                                                    +260
                                                </option>
                                                <option value="MG">
                                                    +261
                                                </option>
                                                <option value="RE">
                                                    +262
                                                </option>
                                                <option value="ZW">
                                                    +263
                                                </option>
                                                <option value="NA">
                                                    +264
                                                </option>
                                                <option value="MW">
                                                    +265
                                                </option>
                                                <option value="LS">
                                                    +266
                                                </option>
                                                <option value="BW">
                                                    +267
                                                </option>
                                                <option value="SZ">
                                                    +268
                                                </option>
                                                <option value="KM">
                                                    +269
                                                </option>
                                                <option value="SH">
                                                    +290
                                                </option>
                                                <option value="ER">
                                                    +291
                                                </option>
                                                <option value="AW">
                                                    +297
                                                </option>
                                                <option value="FO">
                                                    +298
                                                </option>
                                                <option value="GL">
                                                    +299
                                                </option>
                                                <option value="GI">
                                                    +350
                                                </option>
                                                <option value="PT">
                                                    +351
                                                </option>
                                                <option value="LU">
                                                    +352
                                                </option>
                                                <option value="IE">
                                                    +353
                                                </option>
                                                <option value="IS">
                                                    +354
                                                </option>
                                                <option value="AL">
                                                    +355
                                                </option>
                                                <option value="MT">
                                                    +356
                                                </option>
                                                <option value="CY">
                                                    +357
                                                </option>
                                                <option value="FI">
                                                    +358
                                                </option>
                                                <option value="BG">
                                                    +359
                                                </option>
                                                <option value="LT">
                                                    +370
                                                </option>
                                                <option value="LV">
                                                    +371
                                                </option>
                                                <option value="EE">
                                                    +372
                                                </option>
                                                <option value="MD">
                                                    +373
                                                </option>
                                                <option value="AM">
                                                    +374
                                                </option>
                                                <option value="BY">
                                                    +375
                                                </option>
                                                <option value="AD">
                                                    +376
                                                </option>
                                                <option value="MC">
                                                    +377
                                                </option>
                                                <option value="SM">
                                                    +378
                                                </option>
                                                <option value="VA">
                                                    +379
                                                </option>
                                                <option value="UA">
                                                    +380
                                                </option>
                                                <option value="HR">
                                                    +385
                                                </option>
                                                <option value="SI">
                                                    +386
                                                </option>
                                                <option value="BA">
                                                    +387
                                                </option>
                                                <option value="MK">
                                                    +389
                                                </option>
                                                <option value="CZ">
                                                    +420
                                                </option>
                                                <option value="SK">
                                                    +421
                                                </option>
                                                <option value="LI">
                                                    +423
                                                </option>
                                                <option value="FK">
                                                    +500
                                                </option>
                                                <option value="BZ">
                                                    +501
                                                </option>
                                                <option value="GT">
                                                    +502
                                                </option>
                                                <option value="SV">
                                                    +503
                                                </option>
                                                <option value="HN">
                                                    +504
                                                </option>
                                                <option value="NI">
                                                    +505
                                                </option>
                                                <option value="CR">
                                                    +506
                                                </option>
                                                <option value="PA">
                                                    +507
                                                </option>
                                                <option value="PM">
                                                    +508
                                                </option>
                                                <option value="HT">
                                                    +509
                                                </option>
                                                <option value="GP">
                                                    +590
                                                </option>
                                                <option value="BO">
                                                    +591
                                                </option>
                                                <option value="GY">
                                                    +592
                                                </option>
                                                <option value="EC">
                                                    +593
                                                </option>
                                                <option value="GF">
                                                    +594
                                                </option>
                                                <option value="PY">
                                                    +595
                                                </option>
                                                <option value="MQ">
                                                    +596
                                                </option>
                                                <option value="SR">
                                                    +597
                                                </option>
                                                <option value="UY">
                                                    +598
                                                </option>
                                                <option value="AN">
                                                    +599
                                                </option>
                                                <option value="TL">
                                                    +670
                                                </option>
                                                <option value="NF">
                                                    +672
                                                </option>
                                                <option value="BN">
                                                    +673
                                                </option>
                                                <option value="NR">
                                                    +674
                                                </option>
                                                <option value="PG">
                                                    +675
                                                </option>
                                                <option value="TO">
                                                    +676
                                                </option>
                                                <option value="SB">
                                                    +677
                                                </option>
                                                <option value="VU">
                                                    +678
                                                </option>
                                                <option value="FJ">
                                                    +679
                                                </option>
                                                <option value="PW">
                                                    +680
                                                </option>
                                                <option value="WF">
                                                    +681
                                                </option>
                                                <option value="CK">
                                                    +682
                                                </option>
                                                <option value="NU">
                                                    +683
                                                </option>
                                                <option value="WS">
                                                    +685
                                                </option>
                                                <option value="KI">
                                                    +686
                                                </option>
                                                <option value="NC">
                                                    +687
                                                </option>
                                                <option value="TV">
                                                    +688
                                                </option>
                                                <option value="PF">
                                                    +689
                                                </option>
                                                <option value="TK">
                                                    +690
                                                </option>
                                                <option value="FM">
                                                    +691
                                                </option>
                                                <option value="MH">
                                                    +692
                                                </option>
                                                <option value="KP">
                                                    +850
                                                </option>
                                                <option value="HK">
                                                    +852
                                                </option>
                                                <option value="MO">
                                                    +853
                                                </option>
                                                <option value="KH">
                                                    +855
                                                </option>
                                                <option value="LA">
                                                    +856
                                                </option>
                                                <option value="BD">
                                                    +880
                                                </option>
                                                <option value="TW">
                                                    +886
                                                </option>
                                                <option value="MV">
                                                    +960
                                                </option>
                                                <option value="LB">
                                                    +961
                                                </option>
                                                <option value="JO">
                                                    +962
                                                </option>
                                                <option value="SY">
                                                    +963
                                                </option>
                                                <option value="IQ">
                                                    +964
                                                </option>
                                                <option value="KW">
                                                    +965
                                                </option>
                                                <option value="SA">
                                                    +966
                                                </option>
                                                <option value="YE">
                                                    +967
                                                </option>
                                                <option value="OM">
                                                    +968
                                                </option>
                                                <option value="PS">
                                                    +970
                                                </option>
                                                <option value="AE">
                                                    +971
                                                </option>
                                                <option value="IL">
                                                    +972
                                                </option>
                                                <option value="BH">
                                                    +973
                                                </option>
                                                <option value="QA">
                                                    +974
                                                </option>
                                                <option value="BT">
                                                    +975
                                                </option>
                                                <option value="MN">
                                                    +976
                                                </option>
                                                <option value="NP">
                                                    +977
                                                </option>
                                                <option value="TJ">
                                                    +992
                                                </option>
                                                <option value="TM">
                                                    +993
                                                </option>
                                                <option value="AZ">
                                                    +994
                                                </option>
                                                <option value="GE">
                                                    +995
                                                </option>
                                                <option value="KG">
                                                    +996
                                                </option>
                                                <option value="UZ">
                                                    +998
                                                </option>
                                            </select>
                                            <input id="" aria-describedby="" maxlength="15" dir="auto" name="number" aria-invalid="false" value="" type="tel">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--<div class="input-col">-->
                            <!--    <label for=""  class="{{ $errors->has('language') ? 'has-error' :'' }}">-->
                            <!--        Language *-->
                            <!--    </label>-->
                            <!--    <div class="inputColumnTable">-->
                            <!--        <div class="inputColumnRow">-->
                            <!--            <select id="language" aria-describedby="" name="language" aria-invalid="false" class="{{ $errors->has('language') ? 'error' :'' }}">-->
                            <!--                <option id="" selected="selected" value="" disabled="disabled">-->
                            <!--                    Select:-->
                            <!--                </option>-->
                            <!--                <option value="AUT">-->
                            <!--                    Östrich-->
                            <!--                </option>-->
                            <!--                <option value="POR">-->
                            <!--                    Português-->
                            <!--                </option>-->
                            <!--                <option value="DEU">-->
                            <!--                    Deutsch-->
                            <!--                </option>-->
                            <!--                <option value="NLD">-->
                            <!--                    Nederlands, Vlaams-->
                            <!--                </option>-->
                            <!--                <option selected="selected" value="ENG">-->
                            <!--                    English-->
                            <!--                </option>-->
                            <!--                <option value="SPA">-->
                            <!--                    Español-->
                            <!--                </option>-->
                            <!--                <option value="FIN">-->
                            <!--                    Suomen kieli-->
                            <!--                </option>-->
                            <!--                <option value="FRA">-->
                            <!--                    Français-->
                            <!--                </option>-->
                            <!--                <option value="POL">-->
                            <!--                    Polski-->
                            <!--                </option>-->
                            <!--                <option value="HIN">-->
                            <!--                    हिन्दी ; हिंदी-->
                            <!--                </option>-->
                            <!--                <option value="IND">-->
                            <!--                    Bahasa Indonesia-->
                            <!--                </option>-->
                            <!--                <option value="GLE">-->
                            <!--                    Gaeilge-->
                            <!--                </option>-->
                            <!--                <option value="ITA">-->
                            <!--                    Italiano-->
                            <!--                </option>-->
                            <!--                <option value="MSA">-->
                            <!--                    Bahasa Melayu, بهاس ملايو‎-->
                            <!--                </option>-->
                            <!--                <option value="RUS">-->
                            <!--                    русский-->
                            <!--                </option>-->
                            <!--                <option value="SWE">-->
                            <!--                    Svenska-->
                            <!--                </option>-->
                            <!--                <option value="KOR">-->
                            <!--                    한국어-->
                            <!--                </option>-->
                            <!--                <option value="JPN">-->
                            <!--                    日本語-->
                            <!--                </option>-->
                            <!--                <option value="ZHS">-->
                            <!--                    简体中文-->
                            <!--                </option>-->
                            <!--                <option value="ZHT">-->
                            <!--                    繁體中文-->
                            <!--                </option>-->
                            <!--                <option value="ARA">-->
                            <!--                    العربية-->
                            <!--                </option>-->
                            <!--                <option value="PAN">-->
                            <!--                    ਪੰਜਾਬੀ-->
                            <!--                </option>-->
                            <!--            </select>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->

                            <div class="input-col">
                                <label for=""  class="{{ $errors->has('subject_message') ? 'has-error' :'' }}">
                                    Subject of your message*
                                </label>
                                <div class="inputColumnTable">
                                    <div class="inputColumnRow">
                                        <select id="" aria-describedby="" name="subject_message" aria-invalid="false" class="{{ $errors->has('subject_message') ? 'error' :'' }}">
                                            <option id="" value=""> </option>
                                            <option value="Product Information">
                                                Product Information
                                            </option>
                                            <option value="After sales services">
                                                After sales services
                                            </option>
                                            <option value="Online purchases">
                                                Online purchases
                                            </option>
                                            <option value="Stores information">
                                                Stores information
                                            </option>
                                            <option value="About Bangladesh Drip">
                                                About Bangladesh Drip
                                            </option>
                                            <option value="Careers">
                                                Careers
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="input-col">
                                <label for="email" class="fieldLabel " >
                                    Insert your order number
                                </label>
                                <div class="inputColumn">
                                    <div class="inputColumnTable">
                                        <div class="inputColumnRow">
                                            <input id="email" aria-describedby="" maxlength="50" dir="auto" aria-invalid="false" name="old_number"  type="number" autocapitalize="off">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-line  ">
                                <!-- field==== -->
                                <label for="message">
                                </label>
                                <textarea  id="message" aria-describedby="" maxlength="1000" dir="auto" name="message" rows="6" spellcheck="false"></textarea>
                                <div class="maxLength" id="" tabindex="-1">
                                    (1000 characters max)
                                </div>
                            </div>
                        </div>
                        <div class="send-email-btn">
                            <button id="sendMail" class="submitButton functional-link tagClick" data-urlsubmit="" type="submit" name="submit">
                                Send your email
                            </button>
                        </div>
                    </form>

                    <div class="email-use-page-footer" style="font-size: 13px;display: none">
                        There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
@endsection
