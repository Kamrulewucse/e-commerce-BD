@extends('layouts.app')
@section('style')
    <style>
        .page-content-inner {
            padding: 14px 0;
        }

        h1.user-card-title {
            font-size: 18px;
            font-weight: bold;
        }

        h1.account-page-title {
            font-weight: bold;
        }

        label.col-form-label {
            text-align: right;
        }

        input.form-control {
            margin: 8px 0;
            height: 42px;
        }

        h1.user-card-title {
            padding: 8px 0;
        }
        /*@media screen and (max-width: 450px) {*/
        /*    .user-nav {*/
        /*        margin-top: 57px;*/
        /*    }*/
        /*    .user-nav ul li a {*/
        /*        padding: 2px;*/
        /*    }*/
        /*}*/

        h1.other-box-title {
            margin: 25px 0;
        }
        .other-box-sub-title {
            font-size: 19px !important;
            margin: 0 !important;
            padding: 0 !important;
            margin-bottom: 25px !important;
        }
        input.form-control.register-input {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            color: #19110b;
            height: 5rem;
            text-align: left;
            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
            font-style: normal;
            font-weight: 500;
            font-size: 1.5rem;
            letter-spacing: .4px;
            transition: border .3s cubic-bezier(0.39,0.575,0.565,1);
            padding: 0 1rem;
            line-height: 4.5rem;

        }

        .register-label {
            font-size: 13px;
            margin-bottom: 30px;
        }
        .select-input{
            height: 4.5rem;
            line-height: 3.5rem;
            border-radius: 0 !important;
            color: #19110b;

        }
        .date-of-birth-fieldset {
            margin: 0;
            padding: 0;
            border: 0;
        }
      .label {
            color: #19110b;
            display: block;
            margin: 0 0 0.5rem;
            font-weight: 400;
            letter-spacing: .4px;
        }
        .date-of-birth-fieldset legend {
            padding: 0;
        }
        .form-pattern .form-line .inputColumn, .formPattern1 .form-line .inputColumn, .formPattern2 .form-line .inputColumn, .formPattern3 .form-line .inputColumn, .formPattern4 .form-line .inputColumn {
            display: block;
            margin-bottom: 1.5rem;
        }
        @media only screen and (min-width: 48em){
          .date-of-birth-fieldset .displayTableCell {
                padding-right: 0.5rem;
            }
        }

            .displayTableCell {
                display: table-cell;
            }
        select {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #eae8e4;
            border-radius: 0;
            box-shadow: none;
            box-sizing: border-box;
            color: #19110b;
            height: 5rem;
            text-align: left;
            font-family: "Louis Vuitton Web","Helvetica Neue",Helvetica,Arial,sans-serif;
            font-weight: 400;
            font-style: normal;
            font-weight: 500;
            font-size: 1.5rem;
            line-height: 2;
            letter-spacing: .4px;
            transition: border .3s cubic-bezier(0.39,0.575,0.565,1);
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background: #fff url("data:image/svg+xml;charset=utf8,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2080%2080'%20focusable='false'%20aria-hidden='true'%20class='ui-icon-controls-chevron-down'%3E%3Cpath%20fill='%2319110b'%20fill-rule='evenodd'%20d='M46.2%2048.6L17.8%2020.3l-5.5%205.4%2028.4%2028.4%205.4%205.5.1.1.1-.1%205.3-4.5L80%2026.7l-5.5-6.4-28.3%2028.3z'/%3E%3C/svg%3E") no-repeat right 1rem top 50%;
            background-size: 3rem 1.8rem;
            max-width: 100%;
            padding: 0 8rem 0 1rem;
            position: relative;
            text-overflow: ellipsis;
        }
        .readonly-input {
            background: #f6f5f3 !important;
            border: none !important;
        }
        .modal-dialog {
            max-width: 775px;
        }
        button.close-modal-btn {
            background: transparent;
            border: none;
        }

        button.close-modal-btn i {
            color: #000;
            font-size: 23px;
            font-weight: normal !important;
        }

        .modal-title {
            font-weight: bold;
            margin-left: 17px;
        }
        .modal-body {
            position: relative;
            flex: 1 1 auto;
            padding: 1rem 30px;
        }
        .modal-footer {
            justify-content: flex-start;
        }
        .modal-footer {
            padding: 11px 27px;
        }
        .btn-modal-custom {
            padding: 0 4rem;
        }
        .address-book-add-btn {
            font-weight: normal;
            display: inline;
            font-size: 15px;
            padding: 15px 16px;
            background: #f6f5f3 !important;
        }

        .address-book-add-btn:hover {
            background: #EAE8E4 !important;
            border: 1.5px solid #19110B!important;
        }
        button{
            border: 1.5px solid #19110B!important;
        }
        .transferent-btn-style {
            background: transparent!important;
            color: #000!important;
            border: 1.5px solid #19110B!important;
        }
        h2.other-box-name {
            font-weight: bold;
            font-size: 24px;
        }


        #address-book-add-new{
            overflow: hidden;
        }
        .address-new-hid-box {
            top: 100%;
            position: relative;
            transition: all .3s ease-out;
            background: #428bca;
            height: 100%;
        }
        a.cancel-btn-address {
            border: 1px solid #ddd;
            height: 45px;
            width: 45px;
            line-height: 42px;
            text-align: center;
            font-size: 23px;
            color: #000;
            font-weight: 400;
            margin-bottom: 15px;
        }
        @media (min-width: 320px) and (max-width: 400px){
            .btn-next-bg-transparent{
                display: block;
            }
            .btn-next {
                text-align: center;
                color: #fff;
                line-height: 20px;
            }

            select {
                width: 106px;
            }
        }
        @media (min-width: 300px) and (max-width: 900px){
            .btn-next-bg-transparent{
                display: block;
            }
            .btn-next {
                text-align: center;
                color: #fff;
                line-height: 20px;
            }
            select {
                width: 106px;
            }
        }

        /* Credit Card */
        .main-card-info h1 {
            color: #333;
            text-align: center;
            font-size: 28px;
            margin: 20px 0
        }

        .main-card-info h2 { font-size: 24px }

        .main-card-info p {
            font-weight: bold;
            font-size: 18px;
            line-height: 1.5;
            text-align: left;
            margin: 20px auto;
            width: 90%;
            max-width: 360px;
            padding: 10px;
        }

        .main-card-info form {
            width: 98%;
            max-width: 360px;
            margin: 20px auto;
            padding: 15px;

            border: 1px solid #D9DCE3;
            border-radius: 3px;
            background: white;

            overflow: hidden;
        }

        .main-card-info form header {
            background: #000000;
            border-bottom: 1px solid white;
            padding: 1px;
            width: calc(100% + 30px);
            margin: -15px 0 0 -15px;
        } 

        .main-card-info form header h2 {
            color: #F5F5F5;
            margin: 0;
            font-size: 20px;
            padding: 7px;
        }

        .main-card-info .field {
            border-color: #EDEDED;
            border-style: solid;
            border-width: 0 0 1px 0;
            display: flex;
            flex-direction: column;
        }
        .main-card-info .field.full { clear: both }
        .main-card-info .field.adjacent { float: left }
        .main-card-info .field.adjacent+.field.adjacent { border-left-width: 1px } /* brilliant, but breaks */
        .main-card-info .field.adjacent+.field.adjacent label { text-indent: 15px }
        .main-card-info .field.half { width: 50% }
        .main-card-info .field.third { width: calc(100% / 3) }
        .main-card-info .field label, .main-card-info .field input {
                font-size: 14px;
                padding: 15px;
            }
            .main-card-info .field label, .main-card-info .field label+input {
                height: 14px;
                box-sizing: content-box;
                padding-left: 0; padding-right: 0;
            }
            .main-card-info .field label {
                font-weight: bold;
                text-align: center;
                padding-right: 10px;
            }
            .main-card-info .field input {
                border: 0 solid transparent;
                background: transparent;
                -webkit-appearance: none;
                width: 100%;
            }
            .main-card-info .field input:focus { outline: 0 }
            .main-card-info .field input[type="submit"] {
                background: #000;
                color: #F5F5F5;
                border-radius: 3px;
                clear: both;
                margin-top: 15px;
                height: 52px;
            }

        @media (min-width: 360px) {
            .main-card-info .field { flex-direction: row }
            .main-card-info .field label { text-align: left }
        }
        .no-border { border-width: 0 }

        @media (min-width: 320px) and (max-width: 400px){
            
        }
        .credit-cards{
            
        }
    </style>
@endsection
@section('content')
    @include('layouts.partial.user_nav')
    <div class="page-content-inner body-height-full">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="other-box-title text-bold">MY PROFILE</h1>
                    <hr>
                </div>
                <div class="col-md-6">
                    <h1 class="other-box-title">PERSONAL INFORMATION</h1>
                    <div class="other-page-box">
                        <form action="{{ route('account_details_post') }}" method="post">
                            @csrf
                            <div class="row">
                                <label class="col-12 register-label" for="password">TITLE <span class="text-danger">*</span>
                                    <span class="form-group">
                                        <select required name="title" id="title" class="form-control register-input select-input">
                                            <option {{ $user->title == 'Mr' ? 'selected' : '' }} value="Mr">Mr</option>
                                            <option {{ $user->title == 'Mrs' ? 'selected' : '' }} value="Mrs">Mrs</option>
                                            <option {{ $user->title == 'Ms' ? 'selected' : '' }} value="Ms">Ms</option>
                                            <option {{ $user->title == 'Mx' ? 'selected' : '' }} value="Mx">Mx</option>
                                            <option {{ $user->title == null ? 'selected' : '' }} value="null">Prefer not to say</option>
                                        </select>
                                            @error('title')
                                            <span class="text-danger">{{ $message }}</span>
                                         @enderror
                                    </span>
                                </label>
                                <label class="col-12 register-label" for="first_name">FIRST NAME <span
                                        class="text-danger">*</span>
                                    <span class="form-group">
                                        <input  type="text" value="{{ old('first_name',$user->first_name) }}" name="first_name" id="first_name"  class="form-control register-input"
                                               placeholder="FIRST NAME">
                                        @error('first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                </label>
                                <label class="col-12 register-label" for="last_name">LAST NAME <span
                                        class="text-danger">*</span>
                                    <span class="form-group">
                                        <input type="text" value="{{ old('last_name',$user->last_name) }}" name="last_name" id="last_name"  class="form-control register-input"
                                               placeholder="LAST NAME">
                                        @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                </label>
                                <label class="col-12 register-label" for="country">COUNTRY/REGION <span class="text-danger">*</span>
                                    <span class="form-group">
                                        <select name="country" id="country" class="form-control register-input select-input">
                                            <option value="">Select Your Title</option>
                                            @foreach($countries as $country)
                                                <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                            @endforeach

                                        </select>
                                        @error('country')
                                        <span class="text-danger">{{ $message }}</span>
                                      @enderror
                                    </span>
                                </label>
                                <div class="col-12">
                                    <fieldset class="date-of-birth-fieldset">
                                        <legend class="label register-label">
                                            DATE OF BIRTH
                                        </legend>
                                        <div class="inputColumn mb--25">
                                            <div class="displayTableCell ">
                                                <!--  -->
                                                <select required id="dayOfBirthupdateProfileForm" name="day">
                                                    <option value="">
                                                        DATE
                                                    </option>
                                                    @for($i=1; $i <= 31; $i++)
                                                        <option {{ ($user->date_of_birth ? date('d',strtotime($user->date_of_birth)) : '') == $i ? 'selected' : '' }} value="{{ $i }}">{{ $i }}</option>
                                                    @endfor
                                                </select>
                                            </div>
                                            <div class="displayTableCell ">
                                                <!--  -->
                                                <select required id="monthOfBirthupdateProfileForm" title="" aria-invalid="false" name="month">
                                                    <option value="">MONTH</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '01' ? 'selected' : '' }} value="01">January</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '02' ? 'selected' : '' }} value="02">February</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '03' ? 'selected' : '' }} value="03">March</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '04' ? 'selected' : '' }} value="04">April</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '05' ? 'selected' : '' }} value="05">May</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '06' ? 'selected' : '' }} value="06">June</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '07' ? 'selected' : '' }} value="07">July</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '08' ? 'selected' : '' }} value="08">August</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '09' ? 'selected' : '' }} value="09">September</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '10' ? 'selected' : '' }} value="10">October</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '11' ? 'selected' : '' }} value="11">November</option>
                                                    <option {{ ($user->date_of_birth ? date('m',strtotime($user->date_of_birth)) : '') == '12' ? 'selected' : '' }} value="12">December</option>
                                                </select>
                                            </div>
                                            <div class="displayTableCell ">
                                                <select required id="yearOfBirthupdateProfileForm" name="year">
                                                    <option value="">
                                                        YEAR
                                                    </option>
                                                    @for($i=1950; $i <= date('Y'); $i++)
                                                        <option {{ ($user->date_of_birth ? date('Y',strtotime($user->date_of_birth)) : '') == $i ? 'selected' : '' }} value="{{ $i }}">{{ $i }}</option>
                                                    @endfor
                                                </select>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                            <button class="btn-next">Save your information</button>
                        </form>

                    </div>

                </div>
                <div class="col-md-6">
                    <h1 class="other-box-title">MY NEWSLETTER</h1>
                    <div class="other-page-box">
                        @if($newsletter)
                        <p class="email-text">{{ date('M Y',strtotime($newsletter->created_at)) }}</p>
                        @endif
                        <h1 class="other-box-title other-box-sub-title">DISCOVER THE LATEST NEWSLETTER</h1>
                        <a href="{{ route('subscribe_toggle') }}" class="btn-next">{{ $newsletter ? 'Unsubscribe' : 'Subscribe'}}</a>
                    </div>
                    <h1 class="other-box-title">LOGIN INFORMATION</h1>
                    <div class="other-page-box">
                        <label class="col-12 register-label" for="first_name">Email
                            <span class="form-group">
                                <input readonly type="text" value="{{ $user->email }}" class="form-control register-input readonly-input">

                            </span>
                        </label>
                        <label class="col-12 register-label" style="margin-bottom: 0;">Password</label>
                        <button role="button" id="change-password" class="btn-next" style="width: 100px">Change</button>
                    </div>
                    <h1 class="other-box-title">MY ADDRESS BOOK <a id="add-new-address" class="btn-next btn-next-bg-transparent logout-btn address-book-add-btn" style="line-height: 23px;" role="button" >ADD NEW ADDRESS</a></h1>

                    <div id="address-book-list-area">
                        @foreach($detailsAddress as $address)
                            @if ($address['user_id'] == Auth::user()->id)
                                <div class="other-page-box">
                                    <h2 class="other-box-name">{{ $address->city }}</h2>
                                    {{ $address->address_first_name.' '.$address->address_last_name }} <br>
                                    {{ $address->address_1 }}<br>
                                    {{ $address->address_2 }}<br>
                                    Postal Code: {{ $address->postal_code }}<br>
                                    {{ $address->city }}<br>
                                    Mobile Number: {{ $address->mobile_no_1 }}<br><br>
                                    <button role="button" class="btn-next edit-address-details" id="customerEdit" onClick="customerEdit({{ $address->id }})" style="width: 150px">Edit</button>
                                    <button role="button" class="btn-next transferent-btn-style" id="deleteDetails" onClick="deleteDetails({{ $address->id }})" style="width: 150px">Delete</button>
                                </div>
                            @endif
                        @endforeach
                    </div>

                    <div id="address-book-add-new" style="display: none">
                        <div class="other-page-box address-new-hid-box">
                            <div class="cancel-button-area" style="text-align: right">
                                <a id="new-address-cancel" role="button" class="cancel-btn-address">x</a>
                            </div>
                            <div class="row">
                                <label class="col-12 register-label" for="address_list_item"></span>
                                    <span class="form-group">
                                         <select  id="address_list_item" class="form-control register-input select-input">
                                             <option value="">Add New Address</option>
                                             @foreach($detailsAddress as $detail)
                                                @if ($detail['user_id'] == Auth::user()->id)
                                                    <option style="color:#000;" value="{{ $detail->id }}">{{ $detail->description }}</option>
                                                @endif
                                             @endforeach
                                         </select>
                                     </span>
                                </label>
                             </div>
                            <form action="{{ url('address_details_post/'.$user->id) }}" method="POST">
                                @csrf
                                <div class="row">
                                    <label class="col-12 register-label" for="customer_location">ADD ADDRESS <span
                                        class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" name="customer_location" class="form-control register-input"
                                                placeholder="Location">
                                        @error('customer_location')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="description">DESCRIPTION <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('description',$user->description) }}" name="description" id="description"  class="form-control register-input"
                                                placeholder="DESCRIPTION">
                                        @error('description')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="password">TITLE <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <select required name="title" id="title" class="form-control register-input select-input">
                                            <option {{ $user->title == 'Mr' ? 'selected' : '' }} value="Mr">Mr</option>
                                            <option {{ $user->title == 'Mrs' ? 'selected' : '' }} value="Mrs">Mrs</option>
                                            <option {{ $user->title == 'Ms' ? 'selected' : '' }} value="Ms">Ms</option>
                                            <option {{ $user->title == 'Mx' ? 'selected' : '' }} value="Mx">Mx</option>
                                            <option {{ $user->title == null ? 'selected' : '' }} value="null">Prefer not to say</option>
                                        </select>
                                            @error('title')
                                            <span class="text-danger">{{ $message }}</span>
                                         @enderror
                                    </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_first_name">FIRST NAME <span
                                            class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('address_first_name',$user->address_first_name) }}" name="address_first_name" id="address_first_name" class="form-control register-input"
                                                placeholder="FIRST NAME">
                                        @error('address_first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_last_name">LAST NAME <span
                                            class="text-danger">*</span>
                                        <span class="form-group">
                                        <input type="text" value="{{ old('address_last_name',$user->address_last_name) }}" name="address_last_name" id="address_last_name"  class="form-control register-input"
                                               placeholder="LAST NAME">
                                        @error('address_last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="company_name">COMPANY NAME <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('company_name',$user->company_name) }}" name="company_name" id="company_name"  class="form-control register-input"
                                                placeholder="COMPANY NAME">
                                        @error('company_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_one">ADDRESS 1 <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('address_one',$user->address_one) }}" name="address_one" id="address_one"  class="form-control register-input"
                                                placeholder="ADDRESS ONE">
                                        @error('address_one')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_two">ADDRESS 2 <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('address_two',$user->address_two) }}" name="address_two" id="address_two"  class="form-control register-input"
                                                placeholder="ADDRESS TWO">
                                        @error('address_two')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="delivery_address">DELIVERY ADDRESS <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('delivery_address',$user->delivery_address) }}" name="delivery_address" id="delivery_address"  class="form-control register-input"
                                                placeholder="DELEVERY ADDRESS">
                                        @error('delivery_address')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="customer_city">CITY <span
                                        class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" value="{{ old('customer_city',$user->customer_city) }}" name="customer_city" id="customer_city"  class="form-control register-input"
                                                placeholder="FIRST NAME">
                                        @error('customer_city')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="customer_state">STATE <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <select name="customer_state" id="customer_state" class="form-control register-input select-input">
                                            <option value="">Select Your State</option>
                                            <option value="Dhaka">Dhaka</option>
                                            <option value="Khulna">Khulna</option>
                                            <option value="Cumilla">Cumilla</option>
                                            {{-- @foreach($countries as $country)
                                                <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                            @endforeach --}}

                                        </select>
                                        @error('country')
                                        <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="country">COUNTRY/REGION <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <select name="country" id="country" class="form-control register-input select-input">
                                            <option value="">Select Your Country</option>
                                            @foreach($countries as $country)
                                                <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                            @endforeach

                                        </select>
                                        @error('country')
                                        <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="postal_code">POSTAL CODE <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" name="postal_code" id="postal_code"  class="form-control register-input"
                                                placeholder="POSTAL CODE">
                                        @error('postal_code')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="mobile_no_type">MOBILE NUMBER <span class="text-danger">*</span>
                                        <span class="form-group">
                                            <select name="mobile_no_type" id="mobile_no_type" class="form-control register-input select-input">
                                                <option value="Mobile">Mobile</option>
                                                <option value="Home">Home</option>
                                                <option value="Work">Work</option>
                                                {{-- @foreach($countries as $country)
                                                    <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                                @endforeach --}}

                                            </select>
                                            @error('country') 
                                                <span class="text-danger">{{ $message }}</span> 
                                            @enderror 
                                        </span>
                                    </label>
                                    <div class="col-12 field_wrapper">
                                        <fieldset class="date-of-birth-fieldset">
                                            <div class="inputColumn mb--25">
                                                <div class="displayTableCell ">
                                                    <!--  -->
                                                    <select id="dayOfBirthupdateProfileForm" required name="mobile_no_code">
                                                        <option value="US" selected="selected">+1</option>
                                                            <option value="RU">+7</option>
                                                            <option value="EG">+20</option>
                                                            <option value="ZA">+27</option>
                                                            <option value="GR">+30</option>
                                                            <option value="NL">+31</option>
                                                            <option value="BE">+32</option>
                                                            <option value="FR">
                                                            +33
                                                            </option>
                                                            <option value="ES">
                                                            +34
                                                            </option>
                                                            <option value="HU">
                                                            +36
                                                            </option>
                                                            <option value="IT">
                                                            +39
                                                            </option>
                                                            <option value="RO">
                                                            +40
                                                            </option>
                                                            <option value="CH">
                                                            +41
                                                            </option>
                                                            <option value="AT">
                                                            +43
                                                            </option>
                                                            <option value="GB">
                                                            +44
                                                            </option>
                                                            <option value="DK">
                                                            +45
                                                            </option>
                                                            <option value="SE">
                                                            +46
                                                            </option>
                                                            <option value="NO">
                                                            +47
                                                            </option>
                                                            <option value="PL">
                                                            +48
                                                            </option>
                                                            <option value="DE">
                                                            +49
                                                            </option>
                                                            <option value="PE">
                                                            +51
                                                            </option>
                                                            <option value="MX">
                                                            +52
                                                            </option>
                                                            <option value="CU">
                                                            +53
                                                            </option>
                                                            <option value="AR">
                                                            +54
                                                            </option>
                                                            <option value="BR">
                                                            +55
                                                            </option>
                                                            <option value="CL">
                                                            +56
                                                            </option>
                                                            <option value="CO">
                                                            +57
                                                            </option>
                                                            <option value="VE">
                                                            +58
                                                            </option>
                                                            <option value="MY">
                                                            +60
                                                            </option>
                                                            <option value="AU">
                                                            +61
                                                            </option>
                                                            <option value="ID">
                                                            +62
                                                            </option>
                                                            <option value="PH">
                                                            +63
                                                            </option>
                                                            <option value="NZ">
                                                            +64
                                                            </option>
                                                            <option value="SG">
                                                            +65
                                                            </option>
                                                            <option value="TH">
                                                            +66
                                                            </option>
                                                            <option value="JP">
                                                            +81
                                                            </option>
                                                            <option value="KR">
                                                            +82
                                                            </option>
                                                            <option value="VN">
                                                            +84
                                                            </option>
                                                            <option value="CN">
                                                            +86
                                                            </option>
                                                            <option value="TR">
                                                            +90
                                                            </option>
                                                            <option value="IN">
                                                            +91
                                                            </option>
                                                            <option value="PK">
                                                            +92
                                                            </option>
                                                            <option value="AF">
                                                            +93
                                                            </option>
                                                            <option value="LK">
                                                            +94
                                                            </option>
                                                            <option value="MM">
                                                            +95
                                                            </option>
                                                            <option value="IR">
                                                            +98
                                                            </option>
                                                            <option value="MA">
                                                            +212
                                                            </option>
                                                            <option value="DZ">
                                                            +213
                                                            </option>
                                                            <option value="TN">
                                                            +216
                                                            </option>
                                                            <option value="LY">
                                                            +218
                                                            </option>
                                                            <option value="GM">
                                                            +220
                                                            </option>
                                                            <option value="SN">
                                                            +221
                                                            </option>
                                                            <option value="MR">
                                                            +222
                                                            </option>
                                                            <option value="ML">
                                                            +223
                                                            </option>
                                                            <option value="GN">
                                                            +224
                                                            </option>
                                                            <option value="CI">
                                                            +225
                                                            </option>
                                                            <option value="BF">
                                                            +226
                                                            </option>
                                                            <option value="NE">
                                                            +227
                                                            </option>
                                                            <option value="TG">
                                                            +228
                                                            </option>
                                                            <option value="BJ">
                                                            +229
                                                            </option>
                                                            <option value="MU">
                                                            +230
                                                            </option>
                                                            <option value="LR">
                                                            +231
                                                            </option>
                                                            <option value="SL">
                                                            +232
                                                            </option>
                                                            <option value="GH">
                                                            +233
                                                            </option>
                                                            <option value="NG">
                                                            +234
                                                            </option>
                                                            <option value="TD">
                                                            +235
                                                            </option>
                                                            <option value="CF">
                                                            +236
                                                            </option>
                                                            <option value="CM">
                                                            +237
                                                            </option>
                                                            <option value="CV">
                                                            +238
                                                            </option>
                                                            <option value="ST">
                                                            +239
                                                            </option>
                                                            <option value="GQ">
                                                            +240
                                                            </option>
                                                            <option value="GA">
                                                            +241
                                                            </option>
                                                            <option value="CG">
                                                            +242
                                                            </option>
                                                            <option value="CD">
                                                            +243
                                                            </option>
                                                            <option value="AO">
                                                            +244
                                                            </option>
                                                            <option value="GW">
                                                            +245
                                                            </option>
                                                            <option value="IO">
                                                            +246
                                                            </option>
                                                            <option value="SC">
                                                            +248
                                                            </option>
                                                            <option value="SD">
                                                            +249
                                                            </option>
                                                            <option value="RW">
                                                            +250
                                                            </option>
                                                            <option value="ET">
                                                            +251
                                                            </option>
                                                            <option value="SO">
                                                            +252
                                                            </option>
                                                            <option value="DJ">
                                                            +253
                                                            </option>
                                                            <option value="KE">
                                                            +254
                                                            </option>
                                                            <option value="TZ">
                                                            +255
                                                            </option>
                                                            <option value="UG">
                                                            +256
                                                            </option>
                                                            <option value="BI">
                                                            +257
                                                            </option>
                                                            <option value="MZ">
                                                            +258
                                                            </option>
                                                            <option value="ZM">
                                                            +260
                                                            </option>
                                                            <option value="MG">
                                                            +261
                                                            </option>
                                                            <option value="RE">
                                                            +262
                                                            </option>
                                                            <option value="ZW">
                                                            +263
                                                            </option>
                                                            <option value="NA">
                                                            +264
                                                            </option>
                                                            <option value="MW">
                                                            +265
                                                            </option>
                                                            <option value="LS">
                                                            +266
                                                            </option>
                                                            <option value="BW">
                                                            +267
                                                            </option>
                                                            <option value="SZ">
                                                            +268
                                                            </option>
                                                            <option value="KM">
                                                            +269
                                                            </option>
                                                            <option value="SH">
                                                            +290
                                                            </option>
                                                            <option value="ER">
                                                            +291
                                                            </option>
                                                            <option value="AW">
                                                            +297
                                                            </option>
                                                            <option value="FO">
                                                            +298
                                                            </option>
                                                            <option value="GL">
                                                            +299
                                                            </option>
                                                            <option value="GI">
                                                            +350
                                                            </option>
                                                            <option value="PT">
                                                            +351
                                                            </option>
                                                            <option value="LU">
                                                            +352
                                                            </option>
                                                            <option value="IE">
                                                            +353
                                                            </option>
                                                            <option value="IS">
                                                            +354
                                                            </option>
                                                            <option value="AL">
                                                            +355
                                                            </option>
                                                            <option value="MT">
                                                            +356
                                                            </option>
                                                            <option value="CY">
                                                            +357
                                                            </option>
                                                            <option value="FI">
                                                            +358
                                                            </option>
                                                            <option value="BG">
                                                            +359
                                                            </option>
                                                            <option value="LT">
                                                            +370
                                                            </option>
                                                            <option value="LV">
                                                            +371
                                                            </option>
                                                            <option value="EE">
                                                            +372
                                                            </option>
                                                            <option value="MD">
                                                            +373
                                                            </option>
                                                            <option value="AM">
                                                            +374
                                                            </option>
                                                            <option value="BY">
                                                            +375
                                                            </option>
                                                            <option value="AD">
                                                            +376
                                                            </option>
                                                            <option value="MC">
                                                            +377
                                                            </option>
                                                            <option value="SM">
                                                            +378
                                                            </option>
                                                            <option value="VA">
                                                            +379
                                                            </option>
                                                            <option value="UA">
                                                            +380
                                                            </option>
                                                            <option value="HR">
                                                            +385
                                                            </option>
                                                            <option value="SI">
                                                            +386
                                                            </option>
                                                            <option value="BA">
                                                            +387
                                                            </option>
                                                            <option value="MK">
                                                            +389
                                                            </option>
                                                            <option value="CZ">
                                                            +420
                                                            </option>
                                                            <option value="SK">
                                                            +421
                                                            </option>
                                                            <option value="LI">
                                                            +423
                                                            </option>
                                                            <option value="FK">
                                                            +500
                                                            </option>
                                                            <option value="BZ">
                                                            +501
                                                            </option>
                                                            <option value="GT">
                                                            +502
                                                            </option>
                                                            <option value="SV">
                                                            +503
                                                            </option>
                                                            <option value="HN">
                                                            +504
                                                            </option>
                                                            <option value="NI">
                                                            +505
                                                            </option>
                                                            <option value="CR">
                                                            +506
                                                            </option>
                                                            <option value="PA">
                                                            +507
                                                            </option>
                                                            <option value="PM">
                                                            +508
                                                            </option>
                                                            <option value="HT">
                                                            +509
                                                            </option>
                                                            <option value="GP">
                                                            +590
                                                            </option>
                                                            <option value="BO">
                                                            +591
                                                            </option>
                                                            <option value="GY">
                                                            +592
                                                            </option>
                                                            <option value="EC">
                                                            +593
                                                            </option>
                                                            <option value="GF">
                                                            +594
                                                            </option>
                                                            <option value="PY">
                                                            +595
                                                            </option>
                                                            <option value="MQ">
                                                            +596
                                                            </option>
                                                            <option value="SR">
                                                            +597
                                                            </option>
                                                            <option value="UY">
                                                            +598
                                                            </option>
                                                            <option value="AN">
                                                            +599
                                                            </option>
                                                            <option value="TL">
                                                            +670
                                                            </option>
                                                            <option value="NF">
                                                            +672
                                                            </option>
                                                            <option value="BN">
                                                            +673
                                                            </option>
                                                            <option value="NR">
                                                            +674
                                                            </option>
                                                            <option value="PG">
                                                            +675
                                                            </option>
                                                            <option value="TO">
                                                            +676
                                                            </option>
                                                            <option value="SB">
                                                            +677
                                                            </option>
                                                            <option value="VU">
                                                            +678
                                                            </option>
                                                            <option value="FJ">
                                                            +679
                                                            </option>
                                                            <option value="PW">
                                                            +680
                                                            </option>
                                                            <option value="WF">
                                                            +681
                                                            </option>
                                                            <option value="CK">
                                                            +682
                                                            </option>
                                                            <option value="NU">
                                                            +683
                                                            </option>
                                                            <option value="WS">
                                                            +685
                                                            </option>
                                                            <option value="KI">
                                                            +686
                                                            </option>
                                                            <option value="NC">
                                                            +687
                                                            </option>
                                                            <option value="TV">
                                                            +688
                                                            </option>
                                                            <option value="PF">
                                                            +689
                                                            </option>
                                                            <option value="TK">
                                                            +690
                                                            </option>
                                                            <option value="FM">
                                                            +691
                                                            </option>
                                                            <option value="MH">
                                                            +692
                                                            </option>
                                                            <option value="KP">
                                                            +850
                                                            </option>
                                                            <option value="HK">
                                                            +852
                                                            </option>
                                                            <option value="MO">
                                                            +853
                                                            </option>
                                                            <option value="KH">
                                                            +855
                                                            </option>
                                                            <option value="LA">
                                                            +856
                                                            </option>
                                                            <option value="BD">
                                                            +880
                                                            </option>
                                                            <option value="TW">
                                                            +886
                                                            </option>
                                                            <option value="MV">
                                                            +960
                                                            </option>
                                                            <option value="LB">
                                                            +961
                                                            </option>
                                                            <option value="JO">
                                                            +962
                                                            </option>
                                                            <option value="SY">
                                                            +963
                                                            </option>
                                                            <option value="IQ">
                                                            +964
                                                            </option>
                                                            <option value="KW">
                                                            +965
                                                            </option>
                                                            <option value="SA">
                                                            +966
                                                            </option>
                                                            <option value="YE">
                                                            +967
                                                            </option>
                                                            <option value="OM">
                                                            +968
                                                            </option>
                                                            <option value="PS">
                                                            +970
                                                            </option>
                                                            <option value="AE">
                                                            +971
                                                            </option>
                                                            <option value="IL">
                                                            +972
                                                            </option>
                                                            <option value="BH">
                                                            +973
                                                            </option>
                                                            <option value="QA">
                                                            +974
                                                            </option>
                                                            <option value="BT">
                                                            +975
                                                            </option>
                                                            <option value="MN">
                                                            +976
                                                            </option>
                                                            <option value="NP">
                                                            +977
                                                            </option>
                                                            <option value="TJ">
                                                            +992
                                                            </option>
                                                            <option value="TM">
                                                            +993
                                                            </option>
                                                            <option value="AZ">+994</option>
                                                            <option value="GE">
                                                            +995
                                                            </option>
                                                            <option value="KG">
                                                            +996
                                                            </option>
                                                            <option value="UZ">
                                                            +998
                                                            </option>
                                                    </select>
                                                </div>
                                                <div class="displayTableCell ">
                                                    <input type="number" value="" name="mobile_no" id="mobile_no" maxlength="10" class="form-control register-input" style="width: 399px; height: ;" placeholder="NUMBER">
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <div class="col-6">
                                        <a href="javascript:void(0);" class="btn btn-dark add_button" title="Add Attribute" style="margin-bottom:20px; background: #fff; color: #000;"> Add more contact</a>
                                    </div>
                                </div>
                                <button class="btn-next">Save</button>
                            </form>
                        </div>
                    </div>

                    <div id="address-book-edit-now" style="display: none">
                        <div class="other-page-box address-new-hid-box">
                            <div class="cancel-button-area" style="text-align: right">
                                <a id="edit-address-cancel" role="button" class="cancel-btn-address">x</a>
                            </div>
                            <div class="row">
                               <label class="col-12 register-label" for="address_list_item"></span>
                                   <span class="form-group">
                                        <select  id="address_list_item" class="form-control register-input select-input">
                                            <option value="">Add New Address</option>
                                            @foreach($detailsAddress as $detail)
                                                <option style="color:#000;" value="{{ $detail->id }}">{{ $detail->description }}</option>
                                            @endforeach
                                        </select>
                                    </span>
                               </label>
                            </div>
                            <form action="#" >
                                {{-- @csrf --}}
                                <div class="row">
                                    <input type="hidden" name="id" id="addressID">
                                    <input type="hidden" name="user_id" id="addressUserID">
                                    <label class="col-12 register-label" for="customer_location">ADD ADDRESS <span
                                        class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" name="customer_location" id="addressLocation" class="form-control register-input" placeholder="Location">
                                        @error('customer_location')
                                            <span class="text-danger">{{ $message }}</span>addressTitle
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="description">DESCRIPTION <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" name="description" id="addressDescription"  class="form-control register-input"
                                                placeholder="">
                                        @error('description')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="password">TITLE <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <select required name="title" id="addressTitle" class="form-control register-input select-input">
                                            <option {{ $user->title == 'Mr' ? 'selected' : '' }} value="Mr">Mr</option>
                                            <option {{ $user->title == 'Mrs' ? 'selected' : '' }} value="Mrs">Mrs</option>
                                            <option {{ $user->title == 'Ms' ? 'selected' : '' }} value="Ms">Ms</option>
                                            <option {{ $user->title == 'Mx' ? 'selected' : '' }} value="Mx">Mx</option>
                                            <option {{ $user->title == null ? 'selected' : '' }} value="null">Prefer not to say</option>
                                        </select>
                                            @error('title')
                                            <span class="text-danger">{{ $message }}</span>
                                         @enderror
                                    </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_first_name">FIRST NAME <span
                                            class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" name="address_first_name" id="addressFirstname" class="form-control register-input"
                                                placeholder="FIRST NAME">
                                        @error('address_first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_last_name">LAST NAME <span
                                            class="text-danger">*</span>
                                        <span class="form-group">
                                        <input type="text" name="address_last_name" id="addressLastname"  class="form-control register-input"
                                               placeholder="LAST NAME">
                                        @error('address_last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="company_name">COMPANY NAME <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" id="addressCompanyname" name="company_name" class="form-control register-input"
                                                placeholder="">
                                        @error('company_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_one">ADDRESS 1 <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" id="addressOne" name="address_one" class="form-control register-input"
                                                placeholder="">
                                        @error('address_one')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="address_two">ADDRESS 2 <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" id="addressTwo" name="address_two" class="form-control register-input"
                                                placeholder="">
                                        @error('address_two')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="delivery_address">DELIVERY ADDRESS <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" id="addressDeliveryAddress" name="delivery_address" class="form-control register-input"
                                                placeholder="">
                                        @error('delivery_address')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="customer_city">CITY <span
                                        class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" id="addressCity" name="customer_city" class="form-control register-input"
                                                placeholder="FIRST NAME">
                                        @error('customer_city')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="customer_state">STATE <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <select name="customer_state" id="addressStateID" class="form-control register-input select-input">
                                            <option value="">Select Your State</option>
                                            <option value="Dhaka">Dhaka</option>
                                            <option value="Khulna">Khulna</option>
                                            <option value="Cumilla">Cumilla</option>
                                            {{-- @foreach($countries as $country)
                                                <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                            @endforeach --}}

                                        </select>
                                        @error('country')
                                        <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="country">COUNTRY/REGION <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <select name="country" id="addressCountryID" class="form-control register-input select-input">
                                            <option value="">Select Your Country</option>
                                            @foreach($countries as $country)
                                                <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                            @endforeach

                                        </select>
                                        @error('country')
                                        <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="postal_code">POSTAL CODE <span class="text-danger">*</span>
                                        <span class="form-group">
                                        <input  type="text" id="addressPostalCode" name="postal_code" class="form-control register-input"
                                                placeholder="">
                                        @error('postal_code')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        </span>
                                    </label>
                                    <label class="col-12 register-label" for="mobile_no_type">MOBILE NUMBER <span class="text-danger">*</span>
                                        <span class="form-group">
                                            <select name="mobile_no_type" id="addressMobileType1" class="form-control register-input select-input">
                                                <option value="Mobile">Mobile</option>
                                                <option value="Home">Home</option>
                                                <option value="Work">Work</option>
                                                {{-- @foreach($countries as $country)
                                                    <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                                @endforeach --}}

                                            </select>
                                            @error('country') 
                                                <span class="text-danger">{{ $message }}</span> 
                                            @enderror 
                                        </span>
                                    </label>
                                    <div class="col-12 field_wrapper">
                                        <fieldset class="date-of-birth-fieldset">
                                            <div class="inputColumn mb--25">
                                                <div class="displayTableCell ">
                                                    <!--  -->
                                                    <select id="addressNumberCode1" required name="mobile_no_code">
                                                        <option value="US" selected="selected">+1</option>
                                                            <option value="RU">+7</option>
                                                            <option value="EG">+20</option>
                                                            <option value="ZA">+27</option>
                                                            <option value="GR">+30</option>
                                                            <option value="NL">+31</option>
                                                            <option value="BE">+32</option>
                                                            <option value="FR">
                                                            +33
                                                            </option>
                                                            <option value="ES">
                                                            +34
                                                            </option>
                                                            <option value="HU">
                                                            +36
                                                            </option>
                                                            <option value="IT">
                                                            +39
                                                            </option>
                                                            <option value="RO">
                                                            +40
                                                            </option>
                                                            <option value="CH">
                                                            +41
                                                            </option>
                                                            <option value="AT">
                                                            +43
                                                            </option>
                                                            <option value="GB">
                                                            +44
                                                            </option>
                                                            <option value="DK">
                                                            +45
                                                            </option>
                                                            <option value="SE">
                                                            +46
                                                            </option>
                                                            <option value="NO">
                                                            +47
                                                            </option>
                                                            <option value="PL">
                                                            +48
                                                            </option>
                                                            <option value="DE">
                                                            +49
                                                            </option>
                                                            <option value="PE">
                                                            +51
                                                            </option>
                                                            <option value="MX">
                                                            +52
                                                            </option>
                                                            <option value="CU">
                                                            +53
                                                            </option>
                                                            <option value="AR">
                                                            +54
                                                            </option>
                                                            <option value="BR">
                                                            +55
                                                            </option>
                                                            <option value="CL">
                                                            +56
                                                            </option>
                                                            <option value="CO">
                                                            +57
                                                            </option>
                                                            <option value="VE">
                                                            +58
                                                            </option>
                                                            <option value="MY">
                                                            +60
                                                            </option>
                                                            <option value="AU">
                                                            +61
                                                            </option>
                                                            <option value="ID">
                                                            +62
                                                            </option>
                                                            <option value="PH">
                                                            +63
                                                            </option>
                                                            <option value="NZ">
                                                            +64
                                                            </option>
                                                            <option value="SG">
                                                            +65
                                                            </option>
                                                            <option value="TH">
                                                            +66
                                                            </option>
                                                            <option value="JP">
                                                            +81
                                                            </option>
                                                            <option value="KR">
                                                            +82
                                                            </option>
                                                            <option value="VN">
                                                            +84
                                                            </option>
                                                            <option value="CN">
                                                            +86
                                                            </option>
                                                            <option value="TR">
                                                            +90
                                                            </option>
                                                            <option value="IN">
                                                            +91
                                                            </option>
                                                            <option value="PK">
                                                            +92
                                                            </option>
                                                            <option value="AF">
                                                            +93
                                                            </option>
                                                            <option value="LK">
                                                            +94
                                                            </option>
                                                            <option value="MM">
                                                            +95
                                                            </option>
                                                            <option value="IR">
                                                            +98
                                                            </option>
                                                            <option value="MA">
                                                            +212
                                                            </option>
                                                            <option value="DZ">
                                                            +213
                                                            </option>
                                                            <option value="TN">
                                                            +216
                                                            </option>
                                                            <option value="LY">
                                                            +218
                                                            </option>
                                                            <option value="GM">
                                                            +220
                                                            </option>
                                                            <option value="SN">
                                                            +221
                                                            </option>
                                                            <option value="MR">
                                                            +222
                                                            </option>
                                                            <option value="ML">
                                                            +223
                                                            </option>
                                                            <option value="GN">
                                                            +224
                                                            </option>
                                                            <option value="CI">
                                                            +225
                                                            </option>
                                                            <option value="BF">
                                                            +226
                                                            </option>
                                                            <option value="NE">
                                                            +227
                                                            </option>
                                                            <option value="TG">
                                                            +228
                                                            </option>
                                                            <option value="BJ">
                                                            +229
                                                            </option>
                                                            <option value="MU">
                                                            +230
                                                            </option>
                                                            <option value="LR">
                                                            +231
                                                            </option>
                                                            <option value="SL">
                                                            +232
                                                            </option>
                                                            <option value="GH">
                                                            +233
                                                            </option>
                                                            <option value="NG">
                                                            +234
                                                            </option>
                                                            <option value="TD">
                                                            +235
                                                            </option>
                                                            <option value="CF">
                                                            +236
                                                            </option>
                                                            <option value="CM">
                                                            +237
                                                            </option>
                                                            <option value="CV">
                                                            +238
                                                            </option>
                                                            <option value="ST">
                                                            +239
                                                            </option>
                                                            <option value="GQ">
                                                            +240
                                                            </option>
                                                            <option value="GA">
                                                            +241
                                                            </option>
                                                            <option value="CG">
                                                            +242
                                                            </option>
                                                            <option value="CD">
                                                            +243
                                                            </option>
                                                            <option value="AO">
                                                            +244
                                                            </option>
                                                            <option value="GW">
                                                            +245
                                                            </option>
                                                            <option value="IO">
                                                            +246
                                                            </option>
                                                            <option value="SC">
                                                            +248
                                                            </option>
                                                            <option value="SD">
                                                            +249
                                                            </option>
                                                            <option value="RW">
                                                            +250
                                                            </option>
                                                            <option value="ET">
                                                            +251
                                                            </option>
                                                            <option value="SO">
                                                            +252
                                                            </option>
                                                            <option value="DJ">
                                                            +253
                                                            </option>
                                                            <option value="KE">
                                                            +254
                                                            </option>
                                                            <option value="TZ">
                                                            +255
                                                            </option>
                                                            <option value="UG">
                                                            +256
                                                            </option>
                                                            <option value="BI">
                                                            +257
                                                            </option>
                                                            <option value="MZ">
                                                            +258
                                                            </option>
                                                            <option value="ZM">
                                                            +260
                                                            </option>
                                                            <option value="MG">
                                                            +261
                                                            </option>
                                                            <option value="RE">
                                                            +262
                                                            </option>
                                                            <option value="ZW">
                                                            +263
                                                            </option>
                                                            <option value="NA">
                                                            +264
                                                            </option>
                                                            <option value="MW">
                                                            +265
                                                            </option>
                                                            <option value="LS">
                                                            +266
                                                            </option>
                                                            <option value="BW">
                                                            +267
                                                            </option>
                                                            <option value="SZ">
                                                            +268
                                                            </option>
                                                            <option value="KM">
                                                            +269
                                                            </option>
                                                            <option value="SH">
                                                            +290
                                                            </option>
                                                            <option value="ER">
                                                            +291
                                                            </option>
                                                            <option value="AW">
                                                            +297
                                                            </option>
                                                            <option value="FO">
                                                            +298
                                                            </option>
                                                            <option value="GL">
                                                            +299
                                                            </option>
                                                            <option value="GI">
                                                            +350
                                                            </option>
                                                            <option value="PT">
                                                            +351
                                                            </option>
                                                            <option value="LU">
                                                            +352
                                                            </option>
                                                            <option value="IE">
                                                            +353
                                                            </option>
                                                            <option value="IS">
                                                            +354
                                                            </option>
                                                            <option value="AL">
                                                            +355
                                                            </option>
                                                            <option value="MT">
                                                            +356
                                                            </option>
                                                            <option value="CY">
                                                            +357
                                                            </option>
                                                            <option value="FI">
                                                            +358
                                                            </option>
                                                            <option value="BG">
                                                            +359
                                                            </option>
                                                            <option value="LT">
                                                            +370
                                                            </option>
                                                            <option value="LV">
                                                            +371
                                                            </option>
                                                            <option value="EE">
                                                            +372
                                                            </option>
                                                            <option value="MD">
                                                            +373
                                                            </option>
                                                            <option value="AM">
                                                            +374
                                                            </option>
                                                            <option value="BY">
                                                            +375
                                                            </option>
                                                            <option value="AD">
                                                            +376
                                                            </option>
                                                            <option value="MC">
                                                            +377
                                                            </option>
                                                            <option value="SM">
                                                            +378
                                                            </option>
                                                            <option value="VA">
                                                            +379
                                                            </option>
                                                            <option value="UA">
                                                            +380
                                                            </option>
                                                            <option value="HR">
                                                            +385
                                                            </option>
                                                            <option value="SI">
                                                            +386
                                                            </option>
                                                            <option value="BA">
                                                            +387
                                                            </option>
                                                            <option value="MK">
                                                            +389
                                                            </option>
                                                            <option value="CZ">
                                                            +420
                                                            </option>
                                                            <option value="SK">
                                                            +421
                                                            </option>
                                                            <option value="LI">
                                                            +423
                                                            </option>
                                                            <option value="FK">
                                                            +500
                                                            </option>
                                                            <option value="BZ">
                                                            +501
                                                            </option>
                                                            <option value="GT">
                                                            +502
                                                            </option>
                                                            <option value="SV">
                                                            +503
                                                            </option>
                                                            <option value="HN">
                                                            +504
                                                            </option>
                                                            <option value="NI">
                                                            +505
                                                            </option>
                                                            <option value="CR">
                                                            +506
                                                            </option>
                                                            <option value="PA">
                                                            +507
                                                            </option>
                                                            <option value="PM">
                                                            +508
                                                            </option>
                                                            <option value="HT">
                                                            +509
                                                            </option>
                                                            <option value="GP">
                                                            +590
                                                            </option>
                                                            <option value="BO">
                                                            +591
                                                            </option>
                                                            <option value="GY">
                                                            +592
                                                            </option>
                                                            <option value="EC">
                                                            +593
                                                            </option>
                                                            <option value="GF">
                                                            +594
                                                            </option>
                                                            <option value="PY">
                                                            +595
                                                            </option>
                                                            <option value="MQ">
                                                            +596
                                                            </option>
                                                            <option value="SR">
                                                            +597
                                                            </option>
                                                            <option value="UY">
                                                            +598
                                                            </option>
                                                            <option value="AN">
                                                            +599
                                                            </option>
                                                            <option value="TL">
                                                            +670
                                                            </option>
                                                            <option value="NF">
                                                            +672
                                                            </option>
                                                            <option value="BN">
                                                            +673
                                                            </option>
                                                            <option value="NR">
                                                            +674
                                                            </option>
                                                            <option value="PG">
                                                            +675
                                                            </option>
                                                            <option value="TO">
                                                            +676
                                                            </option>
                                                            <option value="SB">
                                                            +677
                                                            </option>
                                                            <option value="VU">
                                                            +678
                                                            </option>
                                                            <option value="FJ">
                                                            +679
                                                            </option>
                                                            <option value="PW">
                                                            +680
                                                            </option>
                                                            <option value="WF">
                                                            +681
                                                            </option>
                                                            <option value="CK">
                                                            +682
                                                            </option>
                                                            <option value="NU">
                                                            +683
                                                            </option>
                                                            <option value="WS">
                                                            +685
                                                            </option>
                                                            <option value="KI">
                                                            +686
                                                            </option>
                                                            <option value="NC">
                                                            +687
                                                            </option>
                                                            <option value="TV">
                                                            +688
                                                            </option>
                                                            <option value="PF">
                                                            +689
                                                            </option>
                                                            <option value="TK">
                                                            +690
                                                            </option>
                                                            <option value="FM">
                                                            +691
                                                            </option>
                                                            <option value="MH">
                                                            +692
                                                            </option>
                                                            <option value="KP">
                                                            +850
                                                            </option>
                                                            <option value="HK">
                                                            +852
                                                            </option>
                                                            <option value="MO">
                                                            +853
                                                            </option>
                                                            <option value="KH">
                                                            +855
                                                            </option>
                                                            <option value="LA">
                                                            +856
                                                            </option>
                                                            <option value="BD">
                                                            +880
                                                            </option>
                                                            <option value="TW">
                                                            +886
                                                            </option>
                                                            <option value="MV">
                                                            +960
                                                            </option>
                                                            <option value="LB">
                                                            +961
                                                            </option>
                                                            <option value="JO">
                                                            +962
                                                            </option>
                                                            <option value="SY">
                                                            +963
                                                            </option>
                                                            <option value="IQ">
                                                            +964
                                                            </option>
                                                            <option value="KW">
                                                            +965
                                                            </option>
                                                            <option value="SA">
                                                            +966
                                                            </option>
                                                            <option value="YE">
                                                            +967
                                                            </option>
                                                            <option value="OM">
                                                            +968
                                                            </option>
                                                            <option value="PS">
                                                            +970
                                                            </option>
                                                            <option value="AE">
                                                            +971
                                                            </option>
                                                            <option value="IL">
                                                            +972
                                                            </option>
                                                            <option value="BH">
                                                            +973
                                                            </option>
                                                            <option value="QA">
                                                            +974
                                                            </option>
                                                            <option value="BT">
                                                            +975
                                                            </option>
                                                            <option value="MN">
                                                            +976
                                                            </option>
                                                            <option value="NP">
                                                            +977
                                                            </option>
                                                            <option value="TJ">
                                                            +992
                                                            </option>
                                                            <option value="TM">
                                                            +993
                                                            </option>
                                                            <option value="AZ">+994</option>
                                                            <option value="GE">
                                                            +995
                                                            </option>
                                                            <option value="KG">
                                                            +996
                                                            </option>
                                                            <option value="UZ">
                                                            +998
                                                            </option>
                                                    </select>
                                                </div>
                                                <div class="displayTableCell ">
                                                    <input  type="text" id="addressMobileNumber1" name="mobile_no" class="form-control register-input" style="width: 398px; height: ;" placeholder="">
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <label class="col-12 register-label" for="mobile_no_type">MOBILE NUMBER <span class="text-danger">*</span>
                                        <span class="form-group">
                                            <select name="mobile_no_type" id="addressMobileType2" class="form-control register-input select-input">
                                                <option value="Mobile">Mobile</option>
                                                <option value="Home">Home</option>
                                                <option value="Work">Work</option>
                                                {{-- @foreach($countries as $country)
                                                    <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                                @endforeach --}}

                                            </select>
                                            @error('country') 
                                                <span class="text-danger">{{ $message }}</span> 
                                            @enderror 
                                        </span>
                                    </label>
                                    <div class="col-12 field_wrapper">
                                        <fieldset class="date-of-birth-fieldset">
                                            <div class="inputColumn mb--25">
                                                <div class="displayTableCell ">
                                                    <!--  -->
                                                    <select id="addressNumberCode2" required name="mobile_no_code">
                                                        <option value="US" selected="selected">+1</option>
                                                            <option value="RU">+7</option>
                                                            <option value="EG">+20</option>
                                                            <option value="ZA">+27</option>
                                                            <option value="GR">+30</option>
                                                            <option value="NL">+31</option>
                                                            <option value="BE">+32</option>
                                                            <option value="FR">
                                                            +33
                                                            </option>
                                                            <option value="ES">
                                                            +34
                                                            </option>
                                                            <option value="HU">
                                                            +36
                                                            </option>
                                                            <option value="IT">
                                                            +39
                                                            </option>
                                                            <option value="RO">
                                                            +40
                                                            </option>
                                                            <option value="CH">
                                                            +41
                                                            </option>
                                                            <option value="AT">
                                                            +43
                                                            </option>
                                                            <option value="GB">
                                                            +44
                                                            </option>
                                                            <option value="DK">
                                                            +45
                                                            </option>
                                                            <option value="SE">
                                                            +46
                                                            </option>
                                                            <option value="NO">
                                                            +47
                                                            </option>
                                                            <option value="PL">
                                                            +48
                                                            </option>
                                                            <option value="DE">
                                                            +49
                                                            </option>
                                                            <option value="PE">
                                                            +51
                                                            </option>
                                                            <option value="MX">
                                                            +52
                                                            </option>
                                                            <option value="CU">
                                                            +53
                                                            </option>
                                                            <option value="AR">
                                                            +54
                                                            </option>
                                                            <option value="BR">
                                                            +55
                                                            </option>
                                                            <option value="CL">
                                                            +56
                                                            </option>
                                                            <option value="CO">
                                                            +57
                                                            </option>
                                                            <option value="VE">
                                                            +58
                                                            </option>
                                                            <option value="MY">
                                                            +60
                                                            </option>
                                                            <option value="AU">
                                                            +61
                                                            </option>
                                                            <option value="ID">
                                                            +62
                                                            </option>
                                                            <option value="PH">
                                                            +63
                                                            </option>
                                                            <option value="NZ">
                                                            +64
                                                            </option>
                                                            <option value="SG">
                                                            +65
                                                            </option>
                                                            <option value="TH">
                                                            +66
                                                            </option>
                                                            <option value="JP">
                                                            +81
                                                            </option>
                                                            <option value="KR">
                                                            +82
                                                            </option>
                                                            <option value="VN">
                                                            +84
                                                            </option>
                                                            <option value="CN">
                                                            +86
                                                            </option>
                                                            <option value="TR">
                                                            +90
                                                            </option>
                                                            <option value="IN">
                                                            +91
                                                            </option>
                                                            <option value="PK">
                                                            +92
                                                            </option>
                                                            <option value="AF">
                                                            +93
                                                            </option>
                                                            <option value="LK">
                                                            +94
                                                            </option>
                                                            <option value="MM">
                                                            +95
                                                            </option>
                                                            <option value="IR">
                                                            +98
                                                            </option>
                                                            <option value="MA">
                                                            +212
                                                            </option>
                                                            <option value="DZ">
                                                            +213
                                                            </option>
                                                            <option value="TN">
                                                            +216
                                                            </option>
                                                            <option value="LY">
                                                            +218
                                                            </option>
                                                            <option value="GM">
                                                            +220
                                                            </option>
                                                            <option value="SN">
                                                            +221
                                                            </option>
                                                            <option value="MR">
                                                            +222
                                                            </option>
                                                            <option value="ML">
                                                            +223
                                                            </option>
                                                            <option value="GN">
                                                            +224
                                                            </option>
                                                            <option value="CI">
                                                            +225
                                                            </option>
                                                            <option value="BF">
                                                            +226
                                                            </option>
                                                            <option value="NE">
                                                            +227
                                                            </option>
                                                            <option value="TG">
                                                            +228
                                                            </option>
                                                            <option value="BJ">
                                                            +229
                                                            </option>
                                                            <option value="MU">
                                                            +230
                                                            </option>
                                                            <option value="LR">
                                                            +231
                                                            </option>
                                                            <option value="SL">
                                                            +232
                                                            </option>
                                                            <option value="GH">
                                                            +233
                                                            </option>
                                                            <option value="NG">
                                                            +234
                                                            </option>
                                                            <option value="TD">
                                                            +235
                                                            </option>
                                                            <option value="CF">
                                                            +236
                                                            </option>
                                                            <option value="CM">
                                                            +237
                                                            </option>
                                                            <option value="CV">
                                                            +238
                                                            </option>
                                                            <option value="ST">
                                                            +239
                                                            </option>
                                                            <option value="GQ">
                                                            +240
                                                            </option>
                                                            <option value="GA">
                                                            +241
                                                            </option>
                                                            <option value="CG">
                                                            +242
                                                            </option>
                                                            <option value="CD">
                                                            +243
                                                            </option>
                                                            <option value="AO">
                                                            +244
                                                            </option>
                                                            <option value="GW">
                                                            +245
                                                            </option>
                                                            <option value="IO">
                                                            +246
                                                            </option>
                                                            <option value="SC">
                                                            +248
                                                            </option>
                                                            <option value="SD">
                                                            +249
                                                            </option>
                                                            <option value="RW">
                                                            +250
                                                            </option>
                                                            <option value="ET">
                                                            +251
                                                            </option>
                                                            <option value="SO">
                                                            +252
                                                            </option>
                                                            <option value="DJ">
                                                            +253
                                                            </option>
                                                            <option value="KE">
                                                            +254
                                                            </option>
                                                            <option value="TZ">
                                                            +255
                                                            </option>
                                                            <option value="UG">
                                                            +256
                                                            </option>
                                                            <option value="BI">
                                                            +257
                                                            </option>
                                                            <option value="MZ">
                                                            +258
                                                            </option>
                                                            <option value="ZM">
                                                            +260
                                                            </option>
                                                            <option value="MG">
                                                            +261
                                                            </option>
                                                            <option value="RE">
                                                            +262
                                                            </option>
                                                            <option value="ZW">
                                                            +263
                                                            </option>
                                                            <option value="NA">
                                                            +264
                                                            </option>
                                                            <option value="MW">
                                                            +265
                                                            </option>
                                                            <option value="LS">
                                                            +266
                                                            </option>
                                                            <option value="BW">
                                                            +267
                                                            </option>
                                                            <option value="SZ">
                                                            +268
                                                            </option>
                                                            <option value="KM">
                                                            +269
                                                            </option>
                                                            <option value="SH">
                                                            +290
                                                            </option>
                                                            <option value="ER">
                                                            +291
                                                            </option>
                                                            <option value="AW">
                                                            +297
                                                            </option>
                                                            <option value="FO">
                                                            +298
                                                            </option>
                                                            <option value="GL">
                                                            +299
                                                            </option>
                                                            <option value="GI">
                                                            +350
                                                            </option>
                                                            <option value="PT">
                                                            +351
                                                            </option>
                                                            <option value="LU">
                                                            +352
                                                            </option>
                                                            <option value="IE">
                                                            +353
                                                            </option>
                                                            <option value="IS">
                                                            +354
                                                            </option>
                                                            <option value="AL">
                                                            +355
                                                            </option>
                                                            <option value="MT">
                                                            +356
                                                            </option>
                                                            <option value="CY">
                                                            +357
                                                            </option>
                                                            <option value="FI">
                                                            +358
                                                            </option>
                                                            <option value="BG">
                                                            +359
                                                            </option>
                                                            <option value="LT">
                                                            +370
                                                            </option>
                                                            <option value="LV">
                                                            +371
                                                            </option>
                                                            <option value="EE">
                                                            +372
                                                            </option>
                                                            <option value="MD">
                                                            +373
                                                            </option>
                                                            <option value="AM">
                                                            +374
                                                            </option>
                                                            <option value="BY">
                                                            +375
                                                            </option>
                                                            <option value="AD">
                                                            +376
                                                            </option>
                                                            <option value="MC">
                                                            +377
                                                            </option>
                                                            <option value="SM">
                                                            +378
                                                            </option>
                                                            <option value="VA">
                                                            +379
                                                            </option>
                                                            <option value="UA">
                                                            +380
                                                            </option>
                                                            <option value="HR">
                                                            +385
                                                            </option>
                                                            <option value="SI">
                                                            +386
                                                            </option>
                                                            <option value="BA">
                                                            +387
                                                            </option>
                                                            <option value="MK">
                                                            +389
                                                            </option>
                                                            <option value="CZ">
                                                            +420
                                                            </option>
                                                            <option value="SK">
                                                            +421
                                                            </option>
                                                            <option value="LI">
                                                            +423
                                                            </option>
                                                            <option value="FK">
                                                            +500
                                                            </option>
                                                            <option value="BZ">
                                                            +501
                                                            </option>
                                                            <option value="GT">
                                                            +502
                                                            </option>
                                                            <option value="SV">
                                                            +503
                                                            </option>
                                                            <option value="HN">
                                                            +504
                                                            </option>
                                                            <option value="NI">
                                                            +505
                                                            </option>
                                                            <option value="CR">
                                                            +506
                                                            </option>
                                                            <option value="PA">
                                                            +507
                                                            </option>
                                                            <option value="PM">
                                                            +508
                                                            </option>
                                                            <option value="HT">
                                                            +509
                                                            </option>
                                                            <option value="GP">
                                                            +590
                                                            </option>
                                                            <option value="BO">
                                                            +591
                                                            </option>
                                                            <option value="GY">
                                                            +592
                                                            </option>
                                                            <option value="EC">
                                                            +593
                                                            </option>
                                                            <option value="GF">
                                                            +594
                                                            </option>
                                                            <option value="PY">
                                                            +595
                                                            </option>
                                                            <option value="MQ">
                                                            +596
                                                            </option>
                                                            <option value="SR">
                                                            +597
                                                            </option>
                                                            <option value="UY">
                                                            +598
                                                            </option>
                                                            <option value="AN">
                                                            +599
                                                            </option>
                                                            <option value="TL">
                                                            +670
                                                            </option>
                                                            <option value="NF">
                                                            +672
                                                            </option>
                                                            <option value="BN">
                                                            +673
                                                            </option>
                                                            <option value="NR">
                                                            +674
                                                            </option>
                                                            <option value="PG">
                                                            +675
                                                            </option>
                                                            <option value="TO">
                                                            +676
                                                            </option>
                                                            <option value="SB">
                                                            +677
                                                            </option>
                                                            <option value="VU">
                                                            +678
                                                            </option>
                                                            <option value="FJ">
                                                            +679
                                                            </option>
                                                            <option value="PW">
                                                            +680
                                                            </option>
                                                            <option value="WF">
                                                            +681
                                                            </option>
                                                            <option value="CK">
                                                            +682
                                                            </option>
                                                            <option value="NU">
                                                            +683
                                                            </option>
                                                            <option value="WS">
                                                            +685
                                                            </option>
                                                            <option value="KI">
                                                            +686
                                                            </option>
                                                            <option value="NC">
                                                            +687
                                                            </option>
                                                            <option value="TV">
                                                            +688
                                                            </option>
                                                            <option value="PF">
                                                            +689
                                                            </option>
                                                            <option value="TK">
                                                            +690
                                                            </option>
                                                            <option value="FM">
                                                            +691
                                                            </option>
                                                            <option value="MH">
                                                            +692
                                                            </option>
                                                            <option value="KP">
                                                            +850
                                                            </option>
                                                            <option value="HK">
                                                            +852
                                                            </option>
                                                            <option value="MO">
                                                            +853
                                                            </option>
                                                            <option value="KH">
                                                            +855
                                                            </option>
                                                            <option value="LA">
                                                            +856
                                                            </option>
                                                            <option value="BD">
                                                            +880
                                                            </option>
                                                            <option value="TW">
                                                            +886
                                                            </option>
                                                            <option value="MV">
                                                            +960
                                                            </option>
                                                            <option value="LB">
                                                            +961
                                                            </option>
                                                            <option value="JO">
                                                            +962
                                                            </option>
                                                            <option value="SY">
                                                            +963
                                                            </option>
                                                            <option value="IQ">
                                                            +964
                                                            </option>
                                                            <option value="KW">
                                                            +965
                                                            </option>
                                                            <option value="SA">
                                                            +966
                                                            </option>
                                                            <option value="YE">
                                                            +967
                                                            </option>
                                                            <option value="OM">
                                                            +968
                                                            </option>
                                                            <option value="PS">
                                                            +970
                                                            </option>
                                                            <option value="AE">
                                                            +971
                                                            </option>
                                                            <option value="IL">
                                                            +972
                                                            </option>
                                                            <option value="BH">
                                                            +973
                                                            </option>
                                                            <option value="QA">
                                                            +974
                                                            </option>
                                                            <option value="BT">
                                                            +975
                                                            </option>
                                                            <option value="MN">
                                                            +976
                                                            </option>
                                                            <option value="NP">
                                                            +977
                                                            </option>
                                                            <option value="TJ">
                                                            +992
                                                            </option>
                                                            <option value="TM">
                                                            +993
                                                            </option>
                                                            <option value="AZ">+994</option>
                                                            <option value="GE">
                                                            +995
                                                            </option>
                                                            <option value="KG">
                                                            +996
                                                            </option>
                                                            <option value="UZ">
                                                            +998
                                                            </option>
                                                    </select>
                                                </div>
                                                <div class="displayTableCell ">
                                                    <input  type="text" id="addressMobileNumber2" name="mobile_no" class="form-control register-input" style="width: 398px; height: ;" placeholder="">
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <label class="col-12 register-label" for="mobile_no_type">MOBILE NUMBER <span class="text-danger">*</span>
                                        <span class="form-group">
                                            <select name="mobile_no_type" id="addressMobileType3" class="form-control register-input select-input">
                                                <option value="Mobile">Mobile</option>
                                                <option value="Home">Home</option>
                                                <option value="Work">Work</option>
                                                {{-- @foreach($countries as $country)
                                                    <option {{ $user->country_id == $country->id ? 'selected' : '' }} value="{{ $country->id }}">{{ $country->name }}</option>
                                                @endforeach --}}

                                            </select>
                                            @error('country') 
                                                <span class="text-danger">{{ $message }}</span> 
                                            @enderror 
                                        </span>
                                    </label>
                                    <div class="col-12 field_wrapper">
                                        <fieldset class="date-of-birth-fieldset">
                                            <div class="inputColumn mb--25">
                                                <div class="displayTableCell ">
                                                    <!--  -->
                                                    <select id="addressNumberCode3" required name="mobile_no_code">
                                                        <option value="US" selected="selected">+1</option>
                                                            <option value="RU">+7</option>
                                                            <option value="EG">+20</option>
                                                            <option value="ZA">+27</option>
                                                            <option value="GR">+30</option>
                                                            <option value="NL">+31</option>
                                                            <option value="BE">+32</option>
                                                            <option value="FR">
                                                            +33
                                                            </option>
                                                            <option value="ES">
                                                            +34
                                                            </option>
                                                            <option value="HU">
                                                            +36
                                                            </option>
                                                            <option value="IT">
                                                            +39
                                                            </option>
                                                            <option value="RO">
                                                            +40
                                                            </option>
                                                            <option value="CH">
                                                            +41
                                                            </option>
                                                            <option value="AT">
                                                            +43
                                                            </option>
                                                            <option value="GB">
                                                            +44
                                                            </option>
                                                            <option value="DK">
                                                            +45
                                                            </option>
                                                            <option value="SE">
                                                            +46
                                                            </option>
                                                            <option value="NO">
                                                            +47
                                                            </option>
                                                            <option value="PL">
                                                            +48
                                                            </option>
                                                            <option value="DE">
                                                            +49
                                                            </option>
                                                            <option value="PE">
                                                            +51
                                                            </option>
                                                            <option value="MX">
                                                            +52
                                                            </option>
                                                            <option value="CU">
                                                            +53
                                                            </option>
                                                            <option value="AR">
                                                            +54
                                                            </option>
                                                            <option value="BR">
                                                            +55
                                                            </option>
                                                            <option value="CL">
                                                            +56
                                                            </option>
                                                            <option value="CO">
                                                            +57
                                                            </option>
                                                            <option value="VE">
                                                            +58
                                                            </option>
                                                            <option value="MY">
                                                            +60
                                                            </option>
                                                            <option value="AU">
                                                            +61
                                                            </option>
                                                            <option value="ID">
                                                            +62
                                                            </option>
                                                            <option value="PH">
                                                            +63
                                                            </option>
                                                            <option value="NZ">
                                                            +64
                                                            </option>
                                                            <option value="SG">
                                                            +65
                                                            </option>
                                                            <option value="TH">
                                                            +66
                                                            </option>
                                                            <option value="JP">
                                                            +81
                                                            </option>
                                                            <option value="KR">
                                                            +82
                                                            </option>
                                                            <option value="VN">
                                                            +84
                                                            </option>
                                                            <option value="CN">
                                                            +86
                                                            </option>
                                                            <option value="TR">
                                                            +90
                                                            </option>
                                                            <option value="IN">
                                                            +91
                                                            </option>
                                                            <option value="PK">
                                                            +92
                                                            </option>
                                                            <option value="AF">
                                                            +93
                                                            </option>
                                                            <option value="LK">
                                                            +94
                                                            </option>
                                                            <option value="MM">
                                                            +95
                                                            </option>
                                                            <option value="IR">
                                                            +98
                                                            </option>
                                                            <option value="MA">
                                                            +212
                                                            </option>
                                                            <option value="DZ">
                                                            +213
                                                            </option>
                                                            <option value="TN">
                                                            +216
                                                            </option>
                                                            <option value="LY">
                                                            +218
                                                            </option>
                                                            <option value="GM">
                                                            +220
                                                            </option>
                                                            <option value="SN">
                                                            +221
                                                            </option>
                                                            <option value="MR">
                                                            +222
                                                            </option>
                                                            <option value="ML">
                                                            +223
                                                            </option>
                                                            <option value="GN">
                                                            +224
                                                            </option>
                                                            <option value="CI">
                                                            +225
                                                            </option>
                                                            <option value="BF">
                                                            +226
                                                            </option>
                                                            <option value="NE">
                                                            +227
                                                            </option>
                                                            <option value="TG">
                                                            +228
                                                            </option>
                                                            <option value="BJ">
                                                            +229
                                                            </option>
                                                            <option value="MU">
                                                            +230
                                                            </option>
                                                            <option value="LR">
                                                            +231
                                                            </option>
                                                            <option value="SL">
                                                            +232
                                                            </option>
                                                            <option value="GH">
                                                            +233
                                                            </option>
                                                            <option value="NG">
                                                            +234
                                                            </option>
                                                            <option value="TD">
                                                            +235
                                                            </option>
                                                            <option value="CF">
                                                            +236
                                                            </option>
                                                            <option value="CM">
                                                            +237
                                                            </option>
                                                            <option value="CV">
                                                            +238
                                                            </option>
                                                            <option value="ST">
                                                            +239
                                                            </option>
                                                            <option value="GQ">
                                                            +240
                                                            </option>
                                                            <option value="GA">
                                                            +241
                                                            </option>
                                                            <option value="CG">
                                                            +242
                                                            </option>
                                                            <option value="CD">
                                                            +243
                                                            </option>
                                                            <option value="AO">
                                                            +244
                                                            </option>
                                                            <option value="GW">
                                                            +245
                                                            </option>
                                                            <option value="IO">
                                                            +246
                                                            </option>
                                                            <option value="SC">
                                                            +248
                                                            </option>
                                                            <option value="SD">
                                                            +249
                                                            </option>
                                                            <option value="RW">
                                                            +250
                                                            </option>
                                                            <option value="ET">
                                                            +251
                                                            </option>
                                                            <option value="SO">
                                                            +252
                                                            </option>
                                                            <option value="DJ">
                                                            +253
                                                            </option>
                                                            <option value="KE">
                                                            +254
                                                            </option>
                                                            <option value="TZ">
                                                            +255
                                                            </option>
                                                            <option value="UG">
                                                            +256
                                                            </option>
                                                            <option value="BI">
                                                            +257
                                                            </option>
                                                            <option value="MZ">
                                                            +258
                                                            </option>
                                                            <option value="ZM">
                                                            +260
                                                            </option>
                                                            <option value="MG">
                                                            +261
                                                            </option>
                                                            <option value="RE">
                                                            +262
                                                            </option>
                                                            <option value="ZW">
                                                            +263
                                                            </option>
                                                            <option value="NA">
                                                            +264
                                                            </option>
                                                            <option value="MW">
                                                            +265
                                                            </option>
                                                            <option value="LS">
                                                            +266
                                                            </option>
                                                            <option value="BW">
                                                            +267
                                                            </option>
                                                            <option value="SZ">
                                                            +268
                                                            </option>
                                                            <option value="KM">
                                                            +269
                                                            </option>
                                                            <option value="SH">
                                                            +290
                                                            </option>
                                                            <option value="ER">
                                                            +291
                                                            </option>
                                                            <option value="AW">
                                                            +297
                                                            </option>
                                                            <option value="FO">
                                                            +298
                                                            </option>
                                                            <option value="GL">
                                                            +299
                                                            </option>
                                                            <option value="GI">
                                                            +350
                                                            </option>
                                                            <option value="PT">
                                                            +351
                                                            </option>
                                                            <option value="LU">
                                                            +352
                                                            </option>
                                                            <option value="IE">
                                                            +353
                                                            </option>
                                                            <option value="IS">
                                                            +354
                                                            </option>
                                                            <option value="AL">
                                                            +355
                                                            </option>
                                                            <option value="MT">
                                                            +356
                                                            </option>
                                                            <option value="CY">
                                                            +357
                                                            </option>
                                                            <option value="FI">
                                                            +358
                                                            </option>
                                                            <option value="BG">
                                                            +359
                                                            </option>
                                                            <option value="LT">
                                                            +370
                                                            </option>
                                                            <option value="LV">
                                                            +371
                                                            </option>
                                                            <option value="EE">
                                                            +372
                                                            </option>
                                                            <option value="MD">
                                                            +373
                                                            </option>
                                                            <option value="AM">
                                                            +374
                                                            </option>
                                                            <option value="BY">
                                                            +375
                                                            </option>
                                                            <option value="AD">
                                                            +376
                                                            </option>
                                                            <option value="MC">
                                                            +377
                                                            </option>
                                                            <option value="SM">
                                                            +378
                                                            </option>
                                                            <option value="VA">
                                                            +379
                                                            </option>
                                                            <option value="UA">
                                                            +380
                                                            </option>
                                                            <option value="HR">
                                                            +385
                                                            </option>
                                                            <option value="SI">
                                                            +386
                                                            </option>
                                                            <option value="BA">
                                                            +387
                                                            </option>
                                                            <option value="MK">
                                                            +389
                                                            </option>
                                                            <option value="CZ">
                                                            +420
                                                            </option>
                                                            <option value="SK">
                                                            +421
                                                            </option>
                                                            <option value="LI">
                                                            +423
                                                            </option>
                                                            <option value="FK">
                                                            +500
                                                            </option>
                                                            <option value="BZ">
                                                            +501
                                                            </option>
                                                            <option value="GT">
                                                            +502
                                                            </option>
                                                            <option value="SV">
                                                            +503
                                                            </option>
                                                            <option value="HN">
                                                            +504
                                                            </option>
                                                            <option value="NI">
                                                            +505
                                                            </option>
                                                            <option value="CR">
                                                            +506
                                                            </option>
                                                            <option value="PA">
                                                            +507
                                                            </option>
                                                            <option value="PM">
                                                            +508
                                                            </option>
                                                            <option value="HT">
                                                            +509
                                                            </option>
                                                            <option value="GP">
                                                            +590
                                                            </option>
                                                            <option value="BO">
                                                            +591
                                                            </option>
                                                            <option value="GY">
                                                            +592
                                                            </option>
                                                            <option value="EC">
                                                            +593
                                                            </option>
                                                            <option value="GF">
                                                            +594
                                                            </option>
                                                            <option value="PY">
                                                            +595
                                                            </option>
                                                            <option value="MQ">
                                                            +596
                                                            </option>
                                                            <option value="SR">
                                                            +597
                                                            </option>
                                                            <option value="UY">
                                                            +598
                                                            </option>
                                                            <option value="AN">
                                                            +599
                                                            </option>
                                                            <option value="TL">
                                                            +670
                                                            </option>
                                                            <option value="NF">
                                                            +672
                                                            </option>
                                                            <option value="BN">
                                                            +673
                                                            </option>
                                                            <option value="NR">
                                                            +674
                                                            </option>
                                                            <option value="PG">
                                                            +675
                                                            </option>
                                                            <option value="TO">
                                                            +676
                                                            </option>
                                                            <option value="SB">
                                                            +677
                                                            </option>
                                                            <option value="VU">
                                                            +678
                                                            </option>
                                                            <option value="FJ">
                                                            +679
                                                            </option>
                                                            <option value="PW">
                                                            +680
                                                            </option>
                                                            <option value="WF">
                                                            +681
                                                            </option>
                                                            <option value="CK">
                                                            +682
                                                            </option>
                                                            <option value="NU">
                                                            +683
                                                            </option>
                                                            <option value="WS">
                                                            +685
                                                            </option>
                                                            <option value="KI">
                                                            +686
                                                            </option>
                                                            <option value="NC">
                                                            +687
                                                            </option>
                                                            <option value="TV">
                                                            +688
                                                            </option>
                                                            <option value="PF">
                                                            +689
                                                            </option>
                                                            <option value="TK">
                                                            +690
                                                            </option>
                                                            <option value="FM">
                                                            +691
                                                            </option>
                                                            <option value="MH">
                                                            +692
                                                            </option>
                                                            <option value="KP">
                                                            +850
                                                            </option>
                                                            <option value="HK">
                                                            +852
                                                            </option>
                                                            <option value="MO">
                                                            +853
                                                            </option>
                                                            <option value="KH">
                                                            +855
                                                            </option>
                                                            <option value="LA">
                                                            +856
                                                            </option>
                                                            <option value="BD">
                                                            +880
                                                            </option>
                                                            <option value="TW">
                                                            +886
                                                            </option>
                                                            <option value="MV">
                                                            +960
                                                            </option>
                                                            <option value="LB">
                                                            +961
                                                            </option>
                                                            <option value="JO">
                                                            +962
                                                            </option>
                                                            <option value="SY">
                                                            +963
                                                            </option>
                                                            <option value="IQ">
                                                            +964
                                                            </option>
                                                            <option value="KW">
                                                            +965
                                                            </option>
                                                            <option value="SA">
                                                            +966
                                                            </option>
                                                            <option value="YE">
                                                            +967
                                                            </option>
                                                            <option value="OM">
                                                            +968
                                                            </option>
                                                            <option value="PS">
                                                            +970
                                                            </option>
                                                            <option value="AE">
                                                            +971
                                                            </option>
                                                            <option value="IL">
                                                            +972
                                                            </option>
                                                            <option value="BH">
                                                            +973
                                                            </option>
                                                            <option value="QA">
                                                            +974
                                                            </option>
                                                            <option value="BT">
                                                            +975
                                                            </option>
                                                            <option value="MN">
                                                            +976
                                                            </option>
                                                            <option value="NP">
                                                            +977
                                                            </option>
                                                            <option value="TJ">
                                                            +992
                                                            </option>
                                                            <option value="TM">
                                                            +993
                                                            </option>
                                                            <option value="AZ">+994</option>
                                                            <option value="GE">
                                                            +995
                                                            </option>
                                                            <option value="KG">
                                                            +996
                                                            </option>
                                                            <option value="UZ">
                                                            +998
                                                            </option>
                                                    </select>
                                                </div>
                                                <div class="displayTableCell ">
                                                    <input  type="text" id="addressMobileNumber3" name="mobile_no" class="form-control register-input" style="width: 398px; height: ;" placeholder="">
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                    {{-- <div class="col-6">
                                        <a href="javascript:void(0);" class="btn btn-dark add_button" title="Add Attribute" style="margin-bottom:20px; background: #fff; color: #000;"> Add more contact</a>
                                    </div> --}}
                                </div>
                                <button class="btn btn-primary save-all-elements" id="save-all-data">Continue</button>
                            </form>
                        </div>
                    </div>

                    <div id="card-list-areas">
                        <h2 style="padding:10px 0px;"><span style="font-weight: bold; padding-right: 20px;">MY CREDIT CARDS</span><a id="add-new-card" class="btn-next btn-next-bg-transparent logout-btn address-book-add-btn add-new-cards" style="line-height: 23px;" role="button" >ADD NEW</a></h2>
                        @foreach($carddetails as $carddetail)
                            @if ($carddetail['user_id'] == Auth::user()->id)
                                <div class="other-page-box" style="margin: 20px 0px;">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p style="color: #000;"> <span style="color: #000; font-weight:500;">Visa</span> <br>
                                            <span>{{ $carddetail->card_number }}</span><br>
                                            <span>Expirations Date: {{ $carddetail->card_expiry }}</span><br>
                                            <span>CVC Number: {{ $carddetail->card_cvc }}</span><br>
                                            <button role="button" class="btn-next transferent-btn-style show-alert-delete-box" id="deleteCard" onClick="deleteCard({{ $carddetail->id }})" style="width: 150px;margin-top: 30px;">Delete</button>
                                            </p>
                                        </div>
                                        <div class="col-md-6 credit-cards" style="text-align: right;"><i class="fa fa-cc-visa fa-10x" style="background: #FFD43B;"></i></div>
                                    </div>	
                                </div>
                            @endif
                        @endforeach
                    </div>
                    <div id="card-insert-areas" style="display: none;">
                        <h2><strong>CREDIT INSERT</strong></h2>
                        <div class="other-page-box">
                            <div class="cancel-button-area" style="text-align: right">
                                <a id="card-cancel" role="button" class="cancel-btn-address">x</a>
                            </div>		
                            <div class="main-card-info">
                                <form action="" id="payment">
                                    <header>
                                        {{-- <h2>Your Cart Details</h2> --}}
                                    </header>
                                    <input type="hidden" name="user_id" value="{{ Auth::user()->id }}" id="userid">
                                    <div class="field full">
                                        <label for="number"></label>
                                        <input type="text" name="card_number" id="cardnumber" maxlength="16" placeholder="Number">
                                    </div>
                                    <div class="field adjacent half">
                                        <label for="expiry"></label>
                                        <input type="text" name="card_expiry" id="cardexpiry" placeholder="expiry">
                                    </div>
                                    <div class="field adjacent half">
                                        <label for="cvc"></label>
                                        <input type="text" name="card_cvc" id="cardcvc" maxlength="3" placeholder="CVC">
                                    </div>
                                    <div class="field full no-border">
                                        <input type="submit" value="submit" class="card-save" id="stripe-submission">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="password-change-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title" id="staticBackdropLabel">PASSWORD RECOVERY TITLE</h1>
                    <button type="button" class="close-modal-btn" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa fa-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="modal-form-password-change" name="modal-form-password-change">
                        <div class="row">
                            <div class="col-12">
                                <span class="text-danger pull-right">Mandatory fields *</span>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="old_password">Old Password <span class="text-danger">*</span></label>
                                    <input type="password" id="old_password" class="form-control register-input" name="old_password">
                                    <span class="text-danger" id="old_password_error"></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="new_password">New Password <span class="text-danger">*</span></label>
                                    <input type="password" id="new_password" class="form-control register-input" name="new_password">
                                    <span class="text-danger" id="new_password_error"></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="confirm_password">Confirm Your Password <span class="text-danger">*</span></label>
                                    <input type="password" id="confirm_password" class="form-control register-input" name="confirm_password">
                                    <span class="text-danger" id="confirm_password_error"></span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <a role="button" id="password-change-submit" class="btn btn-secondary btn-modal-custom">Save</a>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script')
    <!-- sweet alert 2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

    <script>
        $(function (){

            $("#add-new-address").click(function (){
                $("#address-book-add-new").show();
                $("#address-book-list-area").hide();
                $("#address-book-edit-now").hide();
            })
            $("#new-address-cancel").click(function (){
                $("#address-book-add-new").hide();
                $("#address-book-list-area").show();
            })

            $(".edit-address-details").click(function (){
                $("#address-book-edit-now").show();
                $("#address-book-list-area").hide();
            })
            $("#edit-address-cancel").click(function (){
                $("#address-book-edit-now").hide();
                $("#address-book-list-area").show();
            })

            $(".add-new-cards").click(function (){
                $("#card-insert-areas").show();
                $("#card-list-areas").hide();
            })
            $("#card-cancel").click(function (){
                $("#card-insert-areas").hide();
                $("#card-list-areas").show();
            })
            
            

            $("#change-password").click(function (){
                $("#password-change-modal").modal('show');
            })
            $('#password-change-submit').click(function () {
                var formData = new FormData($('#modal-form-password-change')[0]);

                $.ajax({
                    type: "POST",
                    url: "{{ route('ajax_password_change') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            $('#password-change-modal').modal('hide');
                            Swal.fire(
                                'Updated!',
                                response.message,
                                'success'
                            ).then((result) => {
                                location.reload();
                            });
                        } else {
                            if(response.errors.old_password){
                                $("#old_password_error").html(response.errors.old_password);
                            }else{
                                $("#old_password_error").html(' ');
                            }

                            if(response.errors.new_password){
                                $("#new_password_error").html(response.errors.new_password);
                            }else{
                                $("#new_password_error").html(' ');
                            }
                            if(response.errors.confirm_password){
                                $("#confirm_password_error").html(response.errors.confirm_password);
                            }else{
                                $("#confirm_password_error").html(' ');
                            }
                        }
                    }
                });
            });
        })
    </script>

    <script>
        $(document).ready(function(){
            // Product Attributes add/removed script
            var maxField = 4; //Input fields increment limitation
            var addButton = $('.add_button'); //Add button selector
            var wrapper = $('.field_wrapper'); //Input field wrapper
            var fieldHTML = '<label class="col-12 register-label" for="number_type">MOBILE NUMBER <span class="text-danger">*</span><span class="form-group"><select name="mobile_no_type[]" id="mobile_no_type" class="form-control register-input select-input"><option value="Mobile">Mobile</option><option value="Home">Home</option><option value="Work">Work</option></select>@error("country") <span class="text-danger">{{ $message }}</span> @enderror </span></label><div class="col-12"><fieldset class="date-of-birth-fieldset"><div class="inputColumn mb--25"><div class="displayTableCell"><select id="dayOfBirthupdateProfileForm" name="mobile_no_code[]"><option value="US" selected="selected">+1</option><option value="RU">+7</option><option value="EG">+20</option><option value="ZA">+27</option><option value="GR">+30</option><option value="NL">+31</option><option value="BE">+32</option></select></div><div class="displayTableCell"><input type="number" value="" name="mobile_no[]" maxlength="10" id="address_one" class="form-control register-input" style="width: 380px; height: ;" placeholder="NUMBER"></div></div></fieldset></div>  &nbsp;&nbsp;<a href="javascript:void(0);" style="margin-bottom:15px;" class="remove_button">&nbsp;Remove</a>'; //New input field html 
            var x = 1; //Initial field counter is 1
            
            //Once add button is clicked
            $(addButton).click(function(){
                //Check maximum number of input fields
                if(x < maxField){ 
                    x++; //Increment field counter
                    $(wrapper).append(fieldHTML); //Add field html
                }
            });
            
            //Once remove button is clicked
            $(wrapper).on('click', '.remove_button', function(e){
                e.preventDefault();
                $(this).parent('div').remove(); //Remove field html
                x--; //Decrement field counter
            });
        });
    </script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function customerEdit(id){
        // var selected_option = $('#addressStateID option:selected');
        $.ajax({
            type: 'GET',
            url: "{{ route('customer_address_edit') }}",
            dataType:'json',
                data: {id: id},
            success:function(data){
                console.log(data.description);
                // console.log(data.customerName);
                // alert(data.mobile_no_type_1);
                $('#addressID').val(data.id);
                $('#addressUserID').val(data.user_id);
                $('#addressLocation').val(data.customer_location);
                $('#addressDescription').val(data.description);
                $('#addressTitle').val(data.title);
                $('#addressFirstname').val(data.address_first_name);
                $('#addressLastname').val(data.address_last_name);
                $('#addressCompanyname').val(data.company_name);
                $('#addressCountryID').val(data.country_id);
                $('#addressStateID').val(data.state_id);
                $('#addressCity').val(data.city);
                $('#addressDeliveryAddress').val(data.delivery_address);
                $('#addressOne').val(data.address_1);
                $('#addressTwo').val(data.address_2);
                $('#addressPostalCode').val(data.postal_code);
                $('#addressMobileNumber1').val(data.mobile_no_1);
                $('#addressMobileNumber2').val(data.mobile_no_2);
                $('#addressMobileNumber3').val(data.mobile_no_3);
                $('#addressMobileType1').val(data.mobile_no_type_1);
                $('#addressMobileType2').val(data.mobile_no_type_2);
                $('#addressMobileType3').val(data.mobile_no_type_3);
                $('#addressNumberCode1').val(data.mobile_no_code_1);
                $('#addressNumberCode2').val(data.mobile_no_code_2);
                $('#addressNumberCode3').val(data.mobile_no_code_3);

            }
        })
    } // End Product View with Modal

    $('#save-all-data').click(function () {
        var address_id = $('#addressID').val();
        var user_id = $('#addressUserID').val();
        var location = $('#addressLocation').val();
        var description = $('#addressDescription').val();
        var title = $('#addressTitle').val();
        var firstname = $('#addressFirstname').val();
        var lastname = $('#addressLastname').val();
        var companyname = $('#addressCompanyname').val();
        var countryid = $('#addressCountryID').val();
        var stateid = $('#addressStateID').val();
        var addresscity = $('#addressCity').val();
        var deliveryaddress = $('#addressDeliveryAddress').val();
        var addressone = $('#addressOne').val();
        var addresstwo = $('#addressTwo').val();
        var postalcode = $('#addressPostalCode').val();
        var numberone = $('#addressMobileNumber1').val();
        var numbertwo = $('#addressMobileNumber2').val();
        var numberthree = $('#addressMobileNumber3').val();
        var typeone = $('#addressMobileType1').val();
        var typetwo = $('#addressMobileType2').val();
        var typethree = $('#addressMobileType3').val();
        var codeone = $('#addressNumberCode1').val();
        var codetwo = $('#addressNumberCode2').val();
        var codethree = $('#addressNumberCode3').val();
        // e.preventDefault();
        // alert(countryid);
        $.ajax({
            method: "POST",
            url: "{{ route('address_section_update') }}",
            data: {
                address_id:address_id,
                user_id:user_id,
                location:location,
                description:description,
                title:title,
                firstname:firstname,
                lastname:lastname,
                companyname:companyname,
                countryid:countryid,
                stateid:stateid,
                addresscity:addresscity,
                deliveryaddress:deliveryaddress,
                addressone:addressone,
                addresstwo:addresstwo,
                postalcode:postalcode,
                numberone:numberone,
                numbertwo:numbertwo,
                numberthree:numberthree,
                typeone:typeone,
                typetwo:typetwo,
                typethree:typethree,
                codeone:codeone,
                codetwo:codetwo,
                codethree:codethree,
            }
        }).done(function (response) {
            if (response.success) {
                // alert(response.success);
                $("#address-book-edit-now").hide();
                $("#address-book-list-area").show();

            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: response.message,
                });
            }
        });
    });

    function deleteDetails(id){
        $.ajax({
            type: 'GET',
            url: "{{ route('address_details_delete') }}",
            dataType:'json',
                data: {id:id},
            success:function(data){
                // console.log(data.description);
                // alert(data.description);
                // alert("Are You Sure to Delete");
                location.reload();
            }
        })
    } // End Product View with Modal

    function deleteCard(id){
        $.ajax({
            type: 'GET',
            url: "{{ route('card_details_delete') }}",
            dataType:'json',
                data: {id:id},
            success:function(data){
                location.reload();
            }
        })
    } 

    $('.card-save').click(function (event) {
        event.preventDefault();
        let userid = $('#userid').val();
        let cardnumber_id = $('#cardnumber').val();
        let cardexpiry_id = $('#cardexpiry').val();
        let cardcvc_id = $('#cardcvc').val();
        // alert(userid);

        $.ajax({
            type: "POST",
            url: "{{ route('card_submit_post') }}",
            data: {
                userid:userid,
                cardnumber_id:cardnumber_id,
                cardexpiry_id:cardexpiry_id,
                cardcvc_id:cardcvc_id,
            }
        }).done(function (response) {
            if (response.success) {
                // alert(response.success);
                location.reload();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: response.message,
                });
            }
        });
    });

    

    // $(".confirmDelete").click(function(){
    //     var module = $(this).attr('module');
    //     var moduleid = $(this).attr('moduleid');
    //     Swal.fire({
    //         title: 'Are you sure?',
    //         text: "You won't be able to revert this!",
    //         icon: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: '#3085d6',
    //         cancelButtonColor: '#d33',
    //         confirmButtonText: 'Yes, delete it!'
    //     }).then((result) => {
    //         if (result.isConfirmed) {
    //             Swal.fire(
    //                 'Deleted!',
    //                 'Your file has been deleted.',
    //                 'success'
    //             )
    //             window.location = "/delete-"+module+"/"+moduleid;    
    //         }
    //     })
    // })
</script>




@endsection
